
import express, { Request, Response } from 'express';
import cors from 'cors';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { GoogleGenAI, Type } from "@google/genai";

// --- Define __dirname for ES Modules ---
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// --- Custom, Robust API Key Loader ---
let apiKey: string | null = null;
try {
    console.log("Attempting to load API_KEY from .env file...");
    
    const envPath = path.resolve(__dirname, '.env');
    const envTxtPath = path.resolve(__dirname, '.env.txt');
    let filePathToUse: string | null = null;

    if (fs.existsSync(envPath)) {
        filePathToUse = envPath;
        console.log("Found .env file.");
    } else if (fs.existsSync(envTxtPath)) {
        filePathToUse = envTxtPath;
        console.log("File .env not found, but found .env.txt. Using it as a fallback.");
    }

    if (filePathToUse) {
        let fileContent = fs.readFileSync(filePathToUse, 'utf-8');
        // Strip BOM character if it exists (common in Windows files)
        if (fileContent.charCodeAt(0) === 0xFEFF) {
            console.log("BOM character detected, stripping it from file content.");
            fileContent = fileContent.slice(1);
        }

        const lines = fileContent.split(/\r?\n/);
        for (const line of lines) {
            const trimmedLine = line.trim();
            if (trimmedLine.startsWith('#') || trimmedLine === '') {
                continue;
            }

            // Definitive parsing logic: flexible with spaces and case-insensitive.
            const separatorIndex = trimmedLine.indexOf('=');
            if (separatorIndex === -1) {
                continue; // Skip lines without an '='
            }

            const key = trimmedLine.substring(0, separatorIndex).trim().toUpperCase();
            let value = trimmedLine.substring(separatorIndex + 1).trim();

            if (key === 'API_KEY') {
                // Strip surrounding quotes ("..." or '...') from the value
                if ((value.startsWith('"') && value.endsWith('"')) || (value.startsWith("'") && value.endsWith("'"))) {
                    value = value.substring(1, value.length - 1);
                    console.log("Removed surrounding quotes from API_KEY value.");
                }
                apiKey = value;
                break; // Found the key, no need to look further
            }
        }
    }
    
    if (apiKey) {
        console.log("API_KEY successfully parsed and loaded.");
    } else {
        console.warn("API_KEY not found in .env or .env.txt file.");
    }

} catch(e) {
    console.error("An error occurred while reading the .env file:", e);
}


// --- Server and AI Initialization ---
const app = express();
const port = process.env.PORT || 3001;

let ai: GoogleGenAI | null = null;
if (apiKey) {
    try {
        ai = new GoogleGenAI({ apiKey });
        console.log("GoogleGenAI initialized successfully.");
    } catch (error) {
        console.error("Error initializing GoogleGenAI, but the server will continue to run in safe mode.", error);
        ai = null; // Ensure ai is null on failure
    }
} else {
    console.warn("API_KEY is not configured. Server is running in safe mode. AI features will be disabled.");
}

// --- CORE MIDDLEWARE ---
// This order is critical for the app to function correctly.
// 1. CORS for cross-origin requests.
// 2. JSON body parser for API requests.
app.use(cors({
    origin: '*', 
    methods: ['GET', 'POST'],
    allowedHeaders: ['Content-Type'],
}));
app.use(express.json({ limit: '10mb' }));


// --- API ENDPOINTS ---
// All API routes must be registered BEFORE the static file server.

// Status endpoint for the frontend to check server health
app.get('/api/status', (req: Request, res: Response) => {
    res.json({ isAiReady: !!ai });
});


// Generic error handler for AI calls
const handleAiRequest = async (res: Response, logic: () => Promise<any>) => {
    // Guard clause: Check if AI is initialized before every AI call
    if (!ai) {
        return res.status(503).json({ type: 'error', message: 'AI service is not available. Please check the server configuration for an API key.' });
    }

    try {
        const result = await logic();
        res.json(result);
    } catch (error) {
        console.error("AI Request Error:", error.message);
        res.status(500).json({ type: 'error', message: 'An error occurred on the server while communicating with the AI service.', details: error.message });
    }
};

// Endpoint for smart search and fact checking
app.post('/api/smart-search', async (req: Request, res: Response) => {
    const { searchQuery, searchType } = req.body;
    
    if (!searchQuery || !searchType) {
        return res.status(400).json({ type: 'error', message: 'searchQuery and searchType are required.' });
    }

    await handleAiRequest(res, async () => {
        if (searchType === 'address') {
            const locationSchema = { type: Type.OBJECT, properties: { correctedAddress: { type: Type.STRING }, city: { type: Type.STRING }, latitude: { type: Type.NUMBER }, longitude: { type: Type.NUMBER }, reasoning: { type: Type.STRING }, sources: { type: Type.ARRAY, items: { type: Type.OBJECT, properties: { name: { type: Type.STRING }, uri: { type: Type.STRING } }, required: ["name", "uri"] } }, categoryId: { type: Type.STRING, description: "The category ID for the address from the predefined list." } }, required: ["correctedAddress", "city", "latitude", "longitude", "reasoning", "sources", "categoryId"] };
            const finalSchema = { type: Type.OBJECT, properties: { result: locationSchema, conflictingResults: { type: Type.ARRAY, items: { type: Type.OBJECT, properties: { correctedAddress: { type: Type.STRING }, city: { type: Type.STRING }, latitude: { type: Type.NUMBER }, longitude: { type: Type.NUMBER }, reasoning: { type: Type.STRING }, categoryId: { type: Type.STRING } }, required: ["correctedAddress", "city", "latitude", "longitude", "reasoning", "categoryId"] } } } };
            const prompt = `أنت نظام تحقق وتصنيف جغرافي متقدم، مدعوم من Google. مهمتك هي تحديد الموقع الأكثر دقة لـ "${searchQuery}" وتصنيفه ضمن إحدى الفئات المحددة.
الفئات المتاحة هي:
- 'tripoli': طرابلس
- 'tripoli-suburbs': ضواحي طرابلس
- 'misrata': مصراته
- 'benghazi': بنغازي
- 'benghazi-suburbs': ضواحي بنغازي
- 'other-locations': عناوين لا تتبع الفئات السابقة

تعليماتك:
1.  **التحقق من الموقع:** استخدم بحث Google وخرائط Google لتحديد الموقع الأكثر دقة. تحقق من النتيجة مع مصادر متخصصة مثل ويكيبيديا، wikimapia.org, و alwasat.ly.
2.  **التصنيف:** بناءً على الموقع الذي حددته، قم بتعيين 'categoryId' الأكثر ملاءمة من القائمة أعلاه. يجب أن يكون الرد هو المعرف (ID) باللغة الإنجليزية (مثال: 'tripoli').
3.  **تكوين الرد:**
    - إذا وجدت تطابقًا عاليًا، قم بإرجاع النتيجة في حقل 'result' متضمنة 'categoryId'.
    - إذا وجدت تعارضًا كبيرًا (مثال: مدينتان مختلفتان)، أرجع كلا الاحتمالين في 'conflictingResults' واترك 'result' فارغًا.
    - اشرح كيف وصلت إلى استنتاجك في حقل 'reasoning'.
    - يجب أن تدرج قائمة بالمصادر التي استخدمتها وأكدت النتيجة في حقل 'sources'.
    - يجب أن تكون جميع القيم النصية في رد JSON باللغة العربية حصراً، باستثناء 'categoryId'.`;
            const response = await ai.models.generateContent({ model: 'gemini-2.5-flash', contents: prompt, config: { tools: [{ googleSearch: {} }], responseMimeType: "application/json", responseSchema: finalSchema } });
            const analysis = JSON.parse(response.text.trim());
            if (analysis.conflictingResults && analysis.conflictingResults.length > 0) return { type: 'conflict', data: analysis.conflictingResults };
            if (analysis.result) {
                return { type: 'success', mode: 'address', data: { initialResult: analysis.result, verificationText: analysis.result.reasoning, originalQuery: searchQuery, confidenceScore: 4 } };
            }
            return { type: 'error', message: 'لم يتمكن نظام التحقق من العثور على نتيجة موثوقة.' };
        } else { // searchType === 'fact'
            const expert1Prompt = `أنت مساعد خبير من Google. أجب بوضوح وتفصيل باللغة العربية عن السؤال التالي: "${searchQuery}"`;
            const expert2Prompt = `أنت باحث أكاديمي. قدم إجابة دقيقة وموثقة باللغة العربية عن السؤال التالي، مع ذكر المصادر إن أمكن: "${searchQuery}"`;
            const [expert1Res, expert2Res] = await Promise.all([
                ai.models.generateContent({ model: 'gemini-2.5-flash', contents: expert1Prompt }),
                ai.models.generateContent({ model: 'gemini-2.5-flash', contents: expert2Prompt })
            ]);
            const expert1Answer = expert1Res.text;
            const expert2Answer = expert2Res.text;
            const synthesisPrompt = `أنت خبير في تحليل وتوليف المعلومات. لديك إجابتان من مصدرين مختلفين على نفس السؤال. مهمتك هي دائمًا إنتاج إجابة نهائية مفيدة وشاملة. قم بمقارنة الإجابتين، وحدد نقاط الاتفاق والاختلاف. ثم، قم بصياغة إجابة نهائية موحدة وأكثر موثوقية باللغة العربية. إذا كانت الإجابات متعارضة تمامًا، يجب أن توضح هذا التعارض في إجابتك النهائية وتذكر وجهة نظر كل خبير قبل تقديم استنتاجك الخاص إن أمكن. في النهاية، قم بتوفير ملخص من جملة واحدة للإجابة النهائية. السؤال: "${searchQuery}" إجابة الخبير الأول: "${expert1Answer}" إجابة الخبير الثاني: "${expert2Answer}" يجب أن تكون جميع القيم النصية في رد JSON باللغة العربية حصراً.`;
            const synthesisSchema = { type: Type.OBJECT, properties: { synthesizedAnswer: { type: Type.STRING }, summary: { type: Type.STRING }, locations: { type: Type.ARRAY, items: { type: Type.OBJECT, properties: { name: { type: Type.STRING }, latitude: { type: Type.NUMBER }, longitude: { type: Type.NUMBER } } } } }, required: ["synthesizedAnswer", "summary"] };
            const synthesisResponse = await ai.models.generateContent({ model: 'gemini-2.5-flash', contents: synthesisPrompt, config: { responseMimeType: "application/json", responseSchema: synthesisSchema } });
            const finalResult = JSON.parse(synthesisResponse.text.trim());
            return { type: 'success', mode: 'fact', data: { initialResult: { locations: finalResult.locations || [] }, verificationText: finalResult.synthesizedAnswer, factSummary: finalResult.summary, isCrossValidated: true, expert1Answer: expert1Answer, expert2Answer: expert2Answer, originalQuery: searchQuery } };
        }
    });
});

// Endpoint for challenge/arbitration
app.post('/api/challenge', async (req: Request, res: Response) => {
    const { userCorrectedAddress, userNotes, currentVerificationData } = req.body;
    
    if (!userCorrectedAddress || !currentVerificationData) {
        return res.status(400).json({ type: 'error', message: 'userCorrectedAddress and currentVerificationData are required.' });
    }
    
    const originalResult = currentVerificationData?.initialResult?.correctedAddress;
    const originalQuery = currentVerificationData?.originalQuery;
    
    if (!originalQuery) {
        return res.status(400).json({ type: 'error', message: 'Original query not found in verification data.' });
    }
    
    await handleAiRequest(res, async () => {
        const locationSchema = { type: Type.OBJECT, properties: { correctedAddress: { type: Type.STRING }, city: { type: Type.STRING }, latitude: { type: Type.NUMBER }, longitude: { type: Type.NUMBER }, reasoning: { type: Type.STRING }, categoryId: { type: Type.STRING } }, required: ["correctedAddress", "city", "latitude", "longitude", "reasoning", "categoryId"] };
        const prompt = `أنت "المحقق الأعلى" ومهمتك إصدار حكم نهائي وشامل وتصنيف دقيق. لديك المعلومات التالية: - الاستعلام الأصلي: "${originalQuery}" - النتيجة الأولى (من خبير سابق): "${originalResult}" - الطعن المقدم من المستخدم: "${userCorrectedAddress}" مع ملاحظات: "${userNotes}"
الفئات المتاحة للتصنيف: 'tripoli', 'tripoli-suburbs', 'misrata', 'benghazi', 'benghazi-suburbs', 'other-locations'.
تعليمات صارمة جدًا: 1. مهمتك هي التحقق من وجود الموقع في كلا الادعاءين ("${originalResult}" و "${userCorrectedAddress}") باستخدام بحث Google. لا تختر واحدة على الأخرى. 2. قم بإعداد تقرير نهائي ومفصل. إذا كان الموقع موجودًا في كلتا المدينتين، يجب أن يتضمن تقريرك في حقل "reasoning" قسمًا منفصلاً لكل مدينة، يوضح فيه المنطقة المحددة وأهم المعالم المجاورة. 3. بناءً على حكمك النهائي، صنّف العنوان في 'categoryId' الأكثر ملاءمة. 4. في حقل "correctedAddress"، ضع العنوان الأكثر شمولاً الذي يغطي الحقيقة الكاملة (مثال: "شارع جمال عبد الناصر (طرابلس وبنغازي)"). 5. حدد إحداثيات الموقع الأكثر شهرة أو أهمية في حقول "latitude" و "longitude". 6. أجب بصيغة JSON. يجب أن تكون جميع القيم النصية في رد JSON باللغة العربية حصراً، ما عدا 'categoryId'.`;
        const response = await ai.models.generateContent({ model: 'gemini-2.5-flash', contents: prompt, config: { tools: [{ googleSearch: {} }], responseMimeType: "application/json", responseSchema: locationSchema } });
        const finalJudgment = JSON.parse(response.text.trim());
        const finalVerificationText = `حكم نهائي بعد التحقيق الشامل: ${finalJudgment.reasoning}`;
        const newVerificationData = { initialResult: finalJudgment, verificationText: finalVerificationText, isArbitrated: true, originalQuery: originalQuery };
        return { ...newVerificationData, confidenceScore: 5 };
    });
});

// Endpoint for geospatial analysis
app.post('/api/analyze-shape', async (req: Request, res: Response) => {
    const { geoJSON, nearbyAddresses } = req.body;

    if(!geoJSON || !nearbyAddresses) {
        return res.status(400).json({ type: 'error', message: 'geoJSON and nearbyAddresses are required.' });
    }

    await handleAiRequest(res, async () => {
        const schema = {
            type: Type.OBJECT,
            properties: {
                summary: { type: Type.STRING },
                directDistanceKm: { type: Type.NUMBER },
                drivingDistanceKm: { type: Type.NUMBER },
                drivingTimeMinutes: { type: Type.NUMBER },
                areaSqKm: { type: Type.NUMBER },
                perimeterKm: { type: Type.NUMBER },
                containedAddressIds: { type: Type.ARRAY, items: { type: Type.NUMBER } }
            },
            required: ["summary"]
        };
        const addressesString = nearbyAddresses.map(addr => `ID: ${addr.id}, Address: "${addr.original}"`).join('; ');
        const prompt = `أنت محلل جغرافي مكاني. قم بتحليل الشكل الهندسي التالي بصيغة GeoJSON، مع الأخذ في الاعتبار العناوين القريبة.
GeoJSON:
${JSON.stringify(geoJSON)}

العناوين القريبة المحتملة (للرجوع إليها):
${addressesString}

المطلوب:
1.  **summary**: قدم ملخصًا تحليليًا وصفيًا للشكل (مثال: "مضلع يغطي منطقة وسط المدينة").
2.  **areaSqKm / perimeterKm**: إذا كان الشكل مغلقًا (مثل مضلع)، قم بحساب مساحته بالكيلومتر المربع ومحيطه بالكيلومتر.
3.  **directDistanceKm**: إذا كان الشكل خطًا، قم بحساب المسافة المباشرة بين نقطة البداية والنهاية.
4.  **drivingDistanceKm / drivingTimeMinutes**: إذا كان الشكل خطًا، استخدم بحث Google لتقدير مسافة القيادة بالسيارة والوقت المستغرق بالدقائق.
5.  **containedAddressIds**: من قائمة العناوين القريبة المقدمة، حدد فقط معرفات (IDs) العناوين التي تقع **داخل** حدود الشكل المغلق.
6.  أجب بصيغة JSON. يجب أن تكون القيم النصية باللغة العربية.`;
        
        const response = await ai.models.generateContent({ model: 'gemini-2.5-flash', contents: prompt, config: { tools: [{ googleSearch: {} }], responseMimeType: "application/json", responseSchema: schema } });
        return JSON.parse(response.text.trim());
    });
});

// Endpoint for Internal Analysis (Spellcheck & Decomposition)
app.post('/api/batch-analyze-internal', async (req: Request, res: Response) => {
    const { batch, useSpellcheck, useDecomposition } = req.body;
    if (!batch || !Array.isArray(batch)) {
        return res.status(400).json({ type: 'error', message: 'A valid batch of addresses is required.' });
    }

    await handleAiRequest(res, async () => {
        const phoneticSuggestions = [];
        const decompositionResults = [];
        
        const phoneticSchema = { type: Type.OBJECT, properties: { isCorrect: { type: Type.BOOLEAN }, correctedText: { type: Type.STRING }, reason: { type: Type.STRING } }, required: ["isCorrect"] };
        const decompositionSchema = { type: Type.OBJECT, properties: { canBeDecomposed: { type: Type.BOOLEAN }, baseAddress: { type: Type.STRING }, additionalInfo: { type: Type.STRING }, reason: { type: Type.STRING } }, required: ["canBeDecomposed"] };

        for (const address of batch) {
            if (useSpellcheck) {
                const prompt = `أنت خبير في اللهجة الليبية والعناوين. تحقق من العنوان التالي: "${address.original}" بحثًا عن أخطاء إملائية شائعة أو استبدالات صوتية (ق/غ، ج/ز، إلخ). أجب بصيغة JSON. إذا كان العنوان صحيحًا، أرجع 'isCorrect: true'. إذا وجدت تصحيحًا محتملاً، أرجع 'isCorrect: false' مع 'correctedText' و 'reason' للتصحيح.`;
                const response = await ai.models.generateContent({ model: 'gemini-2.5-flash', contents: prompt, config: { responseMimeType: "application/json", responseSchema: phoneticSchema } });
                const result = JSON.parse(response.text.trim());
                if (!result.isCorrect && result.correctedText) {
                    phoneticSuggestions.push({ originalId: address.id, originalText: address.original, correctedText: result.correctedText, reason: result.reason });
                }
            }
            if (useDecomposition) {
                const prompt = `أنت نظام ذكي لتفكيك العناوين. حلل العنوان: "${address.original}". هل يحتوي على معلومات إضافية (مثل "بجوار المسجد"، "اسم محل") يمكن فصلها عن العنوان الأساسي القابل للتوجيه؟ أجب بصيغة JSON. إذا كان العنوان لا يمكن تفكيكه، أرجع 'canBeDecomposed: false'. إذا كان يمكن تفكيكه، أرجع 'canBeDecomposed: true' مع 'baseAddress' (العنوان الأساسي) و 'additionalInfo' (المعلومات الإضافية) و 'reason' للتغيير.`;
                const response = await ai.models.generateContent({ model: 'gemini-2.5-flash', contents: prompt, config: { responseMimeType: "application/json", responseSchema: decompositionSchema } });
                const result = JSON.parse(response.text.trim());
                 if (result.canBeDecomposed && result.baseAddress) {
                    decompositionResults.push({ id: address.id, originalText: address.original, baseAddress: result.baseAddress, additionalInfo: result.additionalInfo, reason: result.reason });
                }
            }
        }
        return { phoneticSuggestions, decompositionResults };
    });
});

// Endpoint for Structuring Addresses for Semantic Analysis
app.post('/api/batch-structure-addresses', async (req: Request, res: Response) => {
    const { batch } = req.body;
     if (!batch || !Array.isArray(batch)) {
        return res.status(400).json({ type: 'error', message: 'A valid batch of addresses is required.' });
    }

    await handleAiRequest(res, async () => {
        const structuredResults = [];
        const schema = { type: Type.OBJECT, properties: { city: { type: Type.STRING }, district: { type: Type.STRING }, street: { type: Type.STRING }, landmark: { type: Type.STRING, description: "أهم معلم قريب أو رقم مبنى إن وجد." } }, required: ["city", "district", "street"] };
        for(const address of batch) {
            const prompt = `قم بتحليل العنوان التالي: "${address.original}" وتقسيمه إلى مكوناته الأساسية. أجب بصيغة JSON.`;
            try {
                const response = await ai.models.generateContent({ model: 'gemini-2.5-flash', contents: prompt, config: { responseMimeType: "application/json", responseSchema: schema } });
                const structured = JSON.parse(response.text.trim());
                structuredResults.push({ id: address.id, structured });
            } catch (e) {
                console.error(`Failed to structure address ID ${address.id}:`, e.message);
            }
        }
        return { structuredResults };
    });
});


// --- SERVE FRONTEND ---
// 3. Static file server for frontend assets (CSS, JS, etc.).
app.use(express.static(path.join(__dirname, '..'))); 

// 4. Catch-all route to serve the main index.html for any other request.
// This is crucial for client-side routing to work.
app.get('*', (req: Request, res: Response) => {
    res.sendFile(path.join(__dirname, '..', 'index.html'));
});

app.listen(port, () => {
    console.log(`Lamora server listening at http://localhost:${port}`);
});
