// worker.ts

// This is a self-contained environment. We need to define any helper functions it needs.
const normalizeArabic = (str: string): string => {
    if (!str) return '';
    // Comprehensive normalization for Arabic characters
    return str
        .replace(/[أإآ]/g, 'ا')
        .replace(/[ى]/g, 'ي')
        .replace(/[ؤ]/g, 'و')
        .replace(/[ة]/g, 'ه')
        .toLowerCase()
        .trim();
};

/**
 * A fast, non-cryptographic 53-bit hash function.
 * This is used to create a small, numeric "fingerprint" of a string,
 * which is much more memory-efficient to store in a Set than the full string.
 * @param {string} str The string to hash.
 * @param {number} [seed=0] An optional seed.
 * @returns {number} A 53-bit hash.
 */
const cyrb53 = (str: string, seed = 0): number => {
    let h1 = 0xdeadbeef ^ seed, h2 = 0x41c6ce57 ^ seed;
    for (let i = 0, ch; i < str.length; i++) {
        ch = str.charCodeAt(i);
        h1 = Math.imul(h1 ^ ch, 2654435761);
        h2 = Math.imul(h2 ^ ch, 1597334677);
    }
    h1 = Math.imul(h1 ^ (h1 >>> 16), 2246822507);
    h1 ^= Math.imul(h2 ^ (h2 >>> 13), 3266489909);
    h2 = Math.imul(h2 ^ (h2 >>> 16), 2246822507);
    h2 ^= Math.imul(h1 ^ (h1 >>> 13), 3266489909);
    return 4294967296 * (2097151 & h2) + (h1 >>> 0);
};


// The main function of the worker is to listen for a message from the main thread.
self.onmessage = (event) => {
    // We expect the data to contain our address lists.
    const { existingAddresses, newAddresses } = event.data;

    // A helper function to post progress messages back to the main thread.
    const postProgress = (message: string) => {
        self.postMessage({ type: 'progress', message });
    };

    try {
        const newItems = [];
        const duplicateItems = [];
        const similarPairs = []; // This is a placeholder, as local analysis doesn't handle similarity.

        // --- Phase 1: Index all existing addresses by their hash fingerprint ---
        // This is extremely memory-efficient compared to storing full strings.
        const existingFingerprints = new Set<number>();
        const totalExisting = existingAddresses.length;
        postProgress(`فهرسة البيانات الحالية... (0/${totalExisting})`);

        for (let i = 0; i < totalExisting; i++) {
            const addr = existingAddresses[i];
            if (addr && typeof addr.original === 'string') {
                const hash = cyrb53(normalizeArabic(addr.original));
                existingFingerprints.add(hash);
            }
            if ((i + 1) % 1000 === 0 || (i + 1) === totalExisting) {
                postProgress(`فهرسة البيانات الحالية... (${i + 1}/${totalExisting})`);
            }
        }

        // --- Phase 2: Analyze the new addresses against the index and themselves ---
        const newFileFingerprints = new Set<number>();
        const totalNew = newAddresses.length;
        postProgress(`تحليل الملف الجديد... (0/${totalNew})`);

        for (let i = 0; i < totalNew; i++) {
            const newAddr = newAddresses[i];
            if (newAddr && typeof newAddr.original === 'string') {
                const newHash = cyrb53(normalizeArabic(newAddr.original));

                // Check for duplicates using the numeric hash
                if (existingFingerprints.has(newHash) || newFileFingerprints.has(newHash)) {
                    duplicateItems.push(newAddr);
                } else {
                    newItems.push(newAddr);
                    newFileFingerprints.add(newHash);
                }
            }
            
            if ((i + 1) % 500 === 0 || (i + 1) === totalNew) {
                postProgress(`تحليل الملف الجديد... (${i + 1}/${totalNew})`);
            }
        }

        // Once everything is done, post the final results back to the main thread.
        self.postMessage({ type: 'done', payload: { newItems, duplicateItems, similarPairs } });

    } catch (error) {
        // If anything goes wrong inside the worker, send an error message back.
        self.postMessage({ type: 'error', message: error.message });
    }
};