
// @ts-nocheck
import * as logic from './logic.ts';
import type { Address, UserData, VerificationData, StructuredAddress, LocationResult, SpellingSuggestion, DecomposedAddress } from './logic.ts';

declare var L: any; // Declare Leaflet library
declare var XLSX: any; // Declare SheetJS library

document.addEventListener('DOMContentLoaded', () => {
    // --- DOM Elements ---
    const root = {
        // User Profile
        welcomeModal: document.getElementById('welcome-modal'),
        usernameInput: document.getElementById('username-input') as HTMLInputElement,
        usernameError: document.getElementById('username-error'),
        welcomeLogoPreview: document.getElementById('welcome-logo-preview') as HTMLImageElement,
        changeLogoBtn: document.getElementById('change-logo-btn'),
        saveUserBtn: document.getElementById('save-user-btn'),
        userProfile: document.getElementById('user-profile'),
        userLogo: document.getElementById('user-logo') as HTMLImageElement,
        userNameEl: document.getElementById('user-name'),
        greetingEl: document.getElementById('greeting'),
        localTimeEl: document.getElementById('local-time'),
        apiStatusDot: document.getElementById('api-status-dot'),
        // Controls
        controlsArea: document.getElementById('controls-area'),
        importBtn: document.getElementById('import-btn'),
        exportBtn: document.getElementById('export-btn'),
        mapViewBtn: document.getElementById('map-view-btn'),
        settingsBtn: document.getElementById('settings-btn'),
        reportsBtn: document.getElementById('reports-btn'),
        aboutBtn: document.getElementById('about-btn'),
        reviewNewBtn: document.getElementById('review-new-btn'),
        fileInput: document.getElementById('file-input') as HTMLInputElement,
        importStatsContainer: document.getElementById('import-stats'),
        statsSuccessEl: document.getElementById('stats-success'),
        statsRejectedEl: document.getElementById('stats-rejected'),
        // Verification Stats
        dataQualityStatsContainer: document.getElementById('data-quality-stats'),
        trustedStatEl: document.getElementById('trusted-stat')?.querySelector('span'),
        needsReviewStatEl: document.getElementById('needs-review-stat')?.querySelector('span'),
        unverifiedStatEl: document.getElementById('unverified-stat')?.querySelector('span'),
        // Search & Filter
        searchInput: document.getElementById('smart-search-input') as HTMLTextAreaElement,
        filterBar: document.getElementById('filter-bar'),
        sortSelect: document.getElementById('sort-select') as HTMLSelectElement,
        viewSwitcher: document.getElementById('view-switcher'),
        searchResultsContainer: document.getElementById('search-results'),
        tableViewContainer: document.getElementById('table-view-container'),
        groupedViewContainer: document.getElementById('grouped-view-container'),
        addressCardTemplate: document.getElementById('address-card-template') as HTMLTemplateElement,
        tableRowTemplate: document.getElementById('table-row-template') as HTMLTemplateElement,
        categoryGroupTemplate: document.getElementById('category-group-template') as HTMLTemplateElement,
        notFoundTemplate: document.getElementById('not-found-template') as HTMLTemplateElement,
        questionNotFoundTemplate: document.getElementById('question-not-found-template') as HTMLTemplateElement,
        // Map View
        mapViewContainer: document.getElementById('map-view-container'),
        mapViewMap: document.getElementById('map-view-map'),
        closeMapViewBtn: document.getElementById('close-map-view-btn'),
        // Modals
        modalBackdrop: document.getElementById('modal-backdrop'),
        editUserModal: document.getElementById('edit-user-modal'),
        editUsernameInput: document.getElementById('edit-username-input') as HTMLInputElement,
        editAddressModal: document.getElementById('edit-address-modal'),
        editAddressInput: document.getElementById('edit-address-input') as HTMLInputElement,
        reclassifyAddressModal: document.getElementById('reclassify-address-modal'),
        reclassifySelect: document.getElementById('reclassify-select') as HTMLSelectElement,
        deleteConfirmModal: document.getElementById('delete-confirm-modal'),
        loaderModal: document.getElementById('loader-modal'),
        loaderText: document.getElementById('loader-text'),
        smartSearchModal: document.getElementById('smart-search-modal'),
        smartSearchDefaultView: document.getElementById('smart-search-default-view'),
        smartSearchConflictView: document.getElementById('smart-search-conflict-view'),
        deepSearchResultsContainer: document.getElementById('deep-search-results-container'),
        verificationResultsContainer: document.getElementById('verification-results-container'),
        citedSourcesContainer: document.getElementById('cited-sources-container'),
        citedSourcesList: document.getElementById('cited-sources-list'),
        mapContainer: document.getElementById('map-container'),
        smartSearchSaveBtn: document.querySelector('#smart-search-modal [data-action="save-smart-search"]'),
        saveFactBtn: document.getElementById('save-fact-btn'),
        smartSearchCancelBtn: document.getElementById('smart-search-cancel-btn'),
        challengeBtn: document.getElementById('challenge-btn'),
        reverifyConfirmModal: document.getElementById('reverify-confirm-modal'),
        quickVerifyModal: document.getElementById('quick-verify-modal'),
        logoSelectorModal: document.getElementById('logo-selector-modal'),
        logoSelectorGallery: document.getElementById('logo-selector-gallery'),
        apiStatusModal: document.getElementById('api-status-modal'),
        // Geospatial Analysis Modal
        geospatialAnalysisModal: document.getElementById('geospatial-analysis-modal'),
        geospatialSummary: document.getElementById('geospatial-summary'),
        geospatialStatsGrid: document.getElementById('geospatial-stats-grid'),
        geospatialContainedAddresses: document.getElementById('geospatial-contained-addresses'),
        geospatialAddressesSection: document.getElementById('geospatial-addresses-section'),
        // Import Flow Modals
        internalReviewModal: document.getElementById('internal-review-modal'),
        importConfirmModal: document.getElementById('import-confirm-modal'),
        useSemanticAnalysisCheckbox: document.getElementById('use-semantic-analysis-checkbox') as HTMLInputElement,
        useSpellcheckAnalysisCheckbox: document.getElementById('use-spellcheck-analysis-checkbox') as HTMLInputElement,
        useDecomposeAnalysisCheckbox: document.getElementById('use-decompose-analysis-checkbox') as HTMLInputElement,
        smartImportModal: document.getElementById('smart-import-modal'),
        internetModal: document.getElementById('internet-required-modal'),
        // Auto-Verify (Gift)
        autoVerifyModal: document.getElementById('auto-verify-modal'),
        autoVerifyList: document.getElementById('auto-verify-list'),
        autoVerifyItemTemplate: document.getElementById('auto-verify-item-template') as HTMLTemplateElement,
        // Cross Validation & Arbitration
        crossValidationModal: document.getElementById('cross-validation-modal'),
        crossValidationInfo: document.getElementById('cross-validation-info'),
        arbitrationBadge: document.getElementById('arbitration-badge'),
        expertOpinionsContainer: document.getElementById('expert-opinions'),
        challengeModal: document.getElementById('challenge-modal'),
        challengeAddressInput: document.getElementById('challenge-address-input') as HTMLTextAreaElement,
        challengeNotesInput: document.getElementById('challenge-notes-input') as HTMLTextAreaElement,
        challengeWarning: document.getElementById('challenge-warning'),
        submitChallengeBtn: document.getElementById('submit-challenge-btn'),
        // Advanced Settings
        advancedSettingsModal: document.getElementById('advanced-settings-modal'),
        exportExcelBtn: document.getElementById('export-excel-btn'),
        clearAllDataBtn: document.getElementById('clear-all-data-btn'),
        clearDataConfirmModal: document.getElementById('clear-data-confirm-modal'),
        confirmClearDataBtn: document.getElementById('confirm-clear-data-btn'),
        // Reports
        reportsModal: document.getElementById('reports-modal'),
        // Share Modal
        shareModal: document.getElementById('share-modal'),
        shareAddressText: document.getElementById('share-address-text'),
        sharePlatformsContainer: document.getElementById('share-platforms-container'),
        // About
        aboutModal: document.getElementById('about-modal'),
        // Toast
        toastContainer: document.getElementById('toast-container'),
        toastTemplate: document.getElementById('toast-template') as HTMLTemplateElement,
        // Reports templates
        topSearchTemplate: document.getElementById('top-search-template') as HTMLTemplateElement,
        logItemTemplate: document.getElementById('log-item-template') as HTMLTemplateElement,
        similarityGroupTemplate: document.getElementById('similarity-group-template-report') as HTMLTemplateElement,
        // Internal Review Templates
        similarSuperGroupTemplate: document.getElementById('similar-super-group-template') as HTMLTemplateElement,
        similarSubGroupTemplate: document.getElementById('similar-sub-group-template') as HTMLTemplateElement,
        similarVariationTemplate: document.getElementById('similar-variation-template') as HTMLTemplateElement,
        duplicateGroupTemplate: document.getElementById('duplicate-group-template') as HTMLTemplateElement,
        phoneticSuggestionTemplate: document.getElementById('phonetic-suggestion-template') as HTMLTemplateElement,
        decomposedItemTemplate: document.getElementById('decomposed-item-template') as HTMLTemplateElement,
        // Smart Import Templates
        newItemTemplate: document.getElementById('new-item-template') as HTMLTemplateElement,
        duplicateItemTemplate: document.getElementById('duplicate-item-template') as HTMLTemplateElement,
        similarPairTemplate: document.getElementById('similar-pair-template') as HTMLTemplateElement,
    };

    // --- UI State & Variables ---
    let timeInterval: number;
    let mapInstances = new Map();
    let tempSelectedLogoSrc = 'https://img.icons8.com/bubbles/100/user.png';

    // --- Utility Functions ---
    const debounce = (func, delay) => {
        let timeout;
        const debounced = (...args) => {
            clearTimeout(timeout);
            timeout = setTimeout(() => func.apply(this, args), delay);
        };
        debounced.flush = () => {
            clearTimeout(timeout);
            func.apply(this, []);
        };
        return debounced;
    };

    const showToast = (message: string, type: 'success' | 'info' | 'danger' = 'info', duration: number = 3000) => {
        if (!root.toastContainer || !root.toastTemplate) return;

        const toastFragment = root.toastTemplate.content.cloneNode(true) as DocumentFragment;
        const toastEl = toastFragment.querySelector('.toast') as HTMLElement;
        const iconEl = toastEl.querySelector('.toast-icon') as HTMLElement;
        const messageEl = toastEl.querySelector('.toast-message') as HTMLElement;

        toastEl.classList.add(type);
        messageEl.textContent = message;

        const icons = {
            success: 'bi-check-circle-fill',
            info: 'bi-info-circle-fill',
            danger: 'bi-exclamation-triangle-fill',
        };
        iconEl.className = `toast-icon bi ${icons[type]}`;

        root.toastContainer.appendChild(toastEl);

        setTimeout(() => {
            toastEl.remove();
        }, duration);
    };

    // --- Render Functions ---
    const updateCategoryCountsUI = () => {
        root.filterBar.innerHTML = '';
        logic.CATEGORIES.forEach(cat => {
            const btn = document.createElement('button');
            btn.className = 'filter-btn';
            btn.dataset.action = 'filter-category';
            btn.dataset.category = cat.id;
            btn.innerHTML = `${cat.name} <span class="category-count">${logic.appState.categoryCounts[cat.id] || 0}</span>`;
            root.filterBar.appendChild(btn);
        });
    };
    
    const updateVerificationStats = () => {
        if (!root.dataQualityStatsContainer) return;
        const { trustedCount, needsReviewCount, unverifiedCount } = logic.getVerificationStats();
    
        if (logic.appState.addresses.length > 0) {
            root.trustedStatEl.textContent = trustedCount.toString();
            root.needsReviewStatEl.textContent = needsReviewCount.toString();
            root.unverifiedStatEl.textContent = unverifiedCount.toString();
            root.dataQualityStatsContainer.classList.remove('hidden');
        } else {
            root.dataQualityStatsContainer.classList.add('hidden');
        }
    };

    const updateReviewNewButton = () => {
        const newCount = logic.appState.addresses.filter(a => a.isNew).length;
        const btn = root.reviewNewBtn;
        if (!btn) return;

        if (newCount > 0) {
            btn.querySelector('.badge').textContent = newCount.toString();
            btn.classList.remove('hidden');
        } else {
            btn.classList.add('hidden');
            if (logic.appState.reviewingNew) {
                logic.appState.reviewingNew = false;
                render(); 
            }
        }
        btn.classList.toggle('active', logic.appState.reviewingNew);
    };
    
    const updateImportStats = (success: number, rejected: number) => {
        root.statsSuccessEl.textContent = success.toString();
        root.statsRejectedEl.textContent = rejected.toString();
        root.importStatsContainer.classList.remove('hidden');
    };

    const render = () => {
        root.searchResultsContainer.classList.add('hidden');
        root.tableViewContainer.classList.add('hidden');
        root.groupedViewContainer.classList.add('hidden');
        document.querySelectorAll('#filter-bar .filter-btn').forEach(btn => {
            btn.classList.toggle('active', !logic.appState.reviewingNew && btn.dataset.category === logic.appState.activeCategory);
        });
        updateReviewNewButton();
        root.viewSwitcher.querySelectorAll('.btn').forEach(btn => {
            btn.classList.toggle('active', btn.dataset.view === logic.appState.currentView);
        });

        const sortedAddresses = logic.getFilteredAndSortedAddresses();
        
        const query = logic.appState.searchQuery.trim();
        if (query) {
             const resultCategories = new Set(sortedAddresses.map(addr => addr.categoryId));
             document.querySelectorAll('#filter-bar .filter-btn').forEach(btn => {
                btn.style.opacity = !resultCategories.size || resultCategories.has(btn.dataset.category) ? '1' : '0.5';
            });
        } else {
             document.querySelectorAll('#filter-bar .filter-btn').forEach(btn => {
                btn.style.opacity = '1';
            });
        }

        root.searchResultsContainer.innerHTML = '';
        root.tableViewContainer.querySelector('tbody').innerHTML = '';
        root.groupedViewContainer.innerHTML = '';

        if (sortedAddresses.length > 0) {
            let fragment = document.createDocumentFragment();
            const itemsToDisplay = (logic.appState.currentView === 'group' || query)
                ? sortedAddresses
                : sortedAddresses.slice(0, logic.appState.displayedItemsCount);
            
            if (logic.appState.currentView === 'card') {
                itemsToDisplay.forEach(addr => fragment.appendChild(createAddressCard(addr)));
                root.searchResultsContainer.appendChild(fragment);
                root.searchResultsContainer.classList.remove('hidden');
            } else if (logic.appState.currentView === 'table') {
                itemsToDisplay.forEach(addr => fragment.appendChild(createTableRow(addr)));
                root.tableViewContainer.querySelector('tbody').appendChild(fragment);
                root.tableViewContainer.classList.remove('hidden');
            } else { // 'group'
                fragment = createGroupedView(itemsToDisplay);
                root.groupedViewContainer.appendChild(fragment);
                root.groupedViewContainer.classList.remove('hidden');
            }
            
            const canLoadMore = sortedAddresses.length > logic.appState.displayedItemsCount && !query;
            if (canLoadMore && (logic.appState.currentView === 'card' || logic.appState.currentView === 'table')) {
                const loadMoreBtn = createLoadMoreButton(sortedAddresses.length);
                if (logic.appState.currentView === 'card') {
                    root.searchResultsContainer.appendChild(loadMoreBtn);
                } else {
                    const table = root.tableViewContainer.querySelector('table');
                    const tfoot = table.tfoot || table.createTFoot();
                    tfoot.innerHTML = '';
                    const row = tfoot.insertRow();
                    const cell = row.insertCell();
                    cell.colSpan = 3;
                    cell.appendChild(loadMoreBtn);
                }
            } else if(logic.appState.currentView === 'table') {
                const table = root.tableViewContainer.querySelector('table');
                if (table.tfoot) table.tfoot.innerHTML = '';
            }

        } else if (query) {
            root.searchResultsContainer.appendChild(createNotFoundCard(query));
            root.searchResultsContainer.classList.remove('hidden');
        }
        updateVerificationStats();
    };

    const createAddressCard = (addr: Address): Node => {
        const card = root.addressCardTemplate.content.cloneNode(true) as DocumentFragment;
        const cardEl = card.querySelector('.address-card');
        cardEl.dataset.id = addr.id.toString();

        if (addr.isNew) cardEl.classList.add('newly-imported');
        if (addr.verificationData?.isHumanVerified) { cardEl.classList.add('human-verified'); card.querySelector('.human-verified-icon').classList.remove('hidden'); }
        if (addr.verificationData?.isArbitrated) { cardEl.classList.add('arbitrated'); card.querySelector('.arbitrated-icon').classList.remove('hidden'); }
        if (addr.isKnowledgeFact) { cardEl.classList.add('knowledge-fact'); card.querySelector('.knowledge-icon').classList.remove('hidden'); if(addr.verificationData?.isCrossValidated) { card.querySelector('.cross-validated-icon').classList.remove('hidden'); } }
        if (addr.notes) { const notesIcon = card.querySelector('.notes-icon'); notesIcon.classList.remove('hidden'); notesIcon.querySelector('.notes-tooltip').textContent = addr.notes; }
        card.querySelector('.address-text').textContent = addr.original;
        card.querySelector('.address-card-category').textContent = addr.categoryName;
        
        const ratingContainer = card.querySelector('.address-card-rating');
        const verifyBtn = card.querySelector('[data-action="verify"]');
        const navigateBtn = card.querySelector('[data-action="navigate"]');

        if (addr.confidenceScore && ratingContainer) {
            let starsHtml = '';
            for (let i = 1; i <= 5; i++) { starsHtml += `<i class="bi star ${i <= addr.confidenceScore ? 'bi-star-fill filled' : 'bi-star empty'}"></i>`; }
            ratingContainer.innerHTML = starsHtml;
            if (verifyBtn && addr.confidenceScore <= 3) { verifyBtn.classList.add('needs-recheck'); verifyBtn.setAttribute('title', 'مستوى الثقة منخفض، ينصح بالتحقق مرة أخرى'); }
        }
        if (addr.suggestedVerificationId && verifyBtn) { verifyBtn.classList.add('quick-verify'); verifyBtn.dataset.action = 'quick-verify'; verifyBtn.setAttribute('title', 'اقتراح تحقق سريع!'); verifyBtn.querySelector('i').className = 'bi bi-stars'; }
        if (!addr.verificationData?.initialResult?.latitude) { navigateBtn.classList.add('hidden'); }
        return card;
    };

    const createTableRow = (addr: Address): Node => {
        const rowFragment = root.tableRowTemplate.content.cloneNode(true) as DocumentFragment;
        const row = rowFragment.querySelector('tr');
        row.dataset.id = addr.id.toString();
        row.querySelector('.table-address-text').textContent = addr.original;
        const select = row.querySelector('.table-category-select');
        select.innerHTML = '';
        logic.CATEGORIES.forEach(cat => { const option = new Option(cat.name, cat.id); if (cat.id === addr.categoryId) option.selected = true; select.appendChild(option); });
        const navigateBtn = row.querySelector('[data-action="navigate"]');
        if (!addr.verificationData?.initialResult?.latitude) { navigateBtn.classList.add('hidden'); }
        const verifyBtn = row.querySelector('[data-action="verify"]');
        if (addr.suggestedVerificationId) { verifyBtn.classList.add('quick-verify'); verifyBtn.dataset.action = 'quick-verify'; verifyBtn.setAttribute('title', 'اقتراح تحقق سريع!'); verifyBtn.querySelector('i').className = 'bi bi-stars'; }
        else if (addr.confidenceScore && addr.confidenceScore <= 3) { verifyBtn.classList.add('needs-recheck'); verifyBtn.setAttribute('title', 'مستوى الثقة منخفض، ينصح بالتحقق مرة أخرى'); }
        return rowFragment;
    };
    
    const createGroupedView = (addresses: Address[]): DocumentFragment => {
        const fragment = document.createDocumentFragment();
        const grouped = addresses.reduce((acc, addr) => { if (!acc[addr.categoryId]) { acc[addr.categoryId] = []; } acc[addr.categoryId].push(addr); return acc; }, {});
        logic.CATEGORIES.forEach(category => {
            if (grouped[category.id]?.length > 0) {
                const groupEl = root.categoryGroupTemplate.content.cloneNode(true) as DocumentFragment;
                const header = groupEl.querySelector('.accordion-header');
                const content = groupEl.querySelector('.accordion-content');
                const contentContainer = groupEl.querySelector('.group-content');
                header.dataset.categoryId = category.id;
                groupEl.querySelector('.category-name').textContent = category.name;
                groupEl.querySelector('.count').textContent = grouped[category.id].length;
                grouped[category.id].forEach(addr => contentContainer.appendChild(createAddressCard(addr)));
                if (logic.appState.expandedCategories.has(category.id)) { header.classList.add('active'); setTimeout(() => content.style.maxHeight = content.scrollHeight + "px", 10); }
                fragment.appendChild(groupEl);
            }
        });
        return fragment;
    };

    const createLoadMoreButton = (totalCount: number): HTMLButtonElement => {
        const btn = document.createElement('button');
        btn.className = 'btn load-more-btn';
        btn.dataset.action = 'load-more';
        const remaining = totalCount - logic.appState.displayedItemsCount;
        btn.textContent = `تحميل ${Math.min(logic.ITEMS_PER_PAGE, remaining)} المزيد (${remaining} متبقي)`;
        return btn;
    };
    
    const createNotFoundCard = (query: string): Node => {
        const template = logic.isQuestion(query) ? root.questionNotFoundTemplate : root.notFoundTemplate;
        const card = template.content.cloneNode(true) as DocumentFragment;
        card.querySelectorAll('.not-found-query').forEach(el => el.textContent = query);
        return card;
    };

    const debouncedRender = debounce(render, 300);

    // --- Modal Management ---
    const showModal = (modal: HTMLElement) => {
        if (!modal) return;
        root.modalBackdrop.classList.remove('hidden');
        modal.classList.remove('hidden');
    };

    const hideModal = (modal: HTMLElement) => {
        if (modal) modal.classList.add('hidden');
        const anyVisibleModal = document.querySelector('.modal:not(.hidden)');
        if (!anyVisibleModal) {
            root.modalBackdrop.classList.add('hidden');
        }
    };
    
    // --- Map View & Drawing ---
    const initializeMapWithDrawing = (mapContainerEl) => {
        if (mapInstances.has(mapContainerEl.id)) { mapInstances.get(mapContainerEl.id).remove(); }
        const map = L.map(mapContainerEl);
        mapInstances.set(mapContainerEl.id, map);
        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', { attribution: '&copy; OpenStreetMap' }).addTo(map);
        let drawnItems = new L.FeatureGroup();
        map.addLayer(drawnItems);
        let analyzeControl = null;
        L.Control.ColorPicker = L.Control.extend({ onAdd: function(map) { const container = L.DomUtil.create('div', 'leaflet-bar custom-map-controls'); const button = L.DomUtil.create('button', 'custom-map-control', container); button.innerHTML = '<i class="bi bi-palette-fill"></i>'; button.title = 'تغيير لون الرسم'; const palette = L.DomUtil.create('div', 'color-picker-palette hidden', container); const colors = ['#3498db', '#e74c3c', '#2ecc71', '#f39c12', '#9b59b6']; colors.forEach(color => { const swatch = L.DomUtil.create('div', 'color-swatch', palette); swatch.style.backgroundColor = color; swatch.dataset.color = color; if(color === this.options.color) swatch.classList.add('active'); L.DomEvent.on(swatch, 'click', () => { this.options.color = color; palette.querySelectorAll('.color-swatch').forEach(s => s.classList.remove('active')); swatch.classList.add('active'); L.DomUtil.addClass(palette, 'hidden'); }); }); L.DomEvent.on(button, 'click', (e) => { L.DomEvent.stopPropagation(e); palette.classList.toggle('hidden'); }); L.DomEvent.disableClickPropagation(container); return container; }, onRemove: function(map) {}, options: { color: '#3498db' } });
        let colorPicker = new L.Control.ColorPicker({ position: 'topleft' });
        map.addControl(colorPicker);
        let drawControl = new L.Control.Draw({ position: 'topleft', draw: { polygon: { shapeOptions: { color: () => colorPicker.options.color } }, polyline: { shapeOptions: { color: () => colorPicker.options.color } }, rectangle: { shapeOptions: { color: () => colorPicker.options.color } }, circle: { shapeOptions: { color: () => colorPicker.options.color } }, marker: false, circlemarker: false }, edit: { featureGroup: drawnItems, remove: true } });
        map.addControl(drawControl);
        map.on(L.Draw.Event.CREATED, function (e) { const layer = e.layer; layer.options.color = colorPicker.options.color; drawnItems.addLayer(layer); if (drawnItems.getLayers().length > 0 && !analyzeControl) { analyzeControl = L.control({position: 'topleft'}); analyzeControl.onAdd = function (map) { const container = L.DomUtil.create('div', 'leaflet-bar'); const button = L.DomUtil.create('button', 'custom-map-control analyze-shape-btn', container); button.innerHTML = '<i class="bi bi-bullseye"></i> تحليل الشكل'; button.title = 'تحليل الشكل المرسوم'; L.DomEvent.on(button, 'click', () => handleAnalyzeShape(drawnItems)); return container; }; analyzeControl.addTo(map); } });
        map.on(L.Draw.Event.DELETED, function(e) { if(drawnItems.getLayers().length === 0 && analyzeControl) { map.removeControl(analyzeControl); analyzeControl = null; } });
        return map;
    };
    
    const openMapView = () => {
        const addressesToDisplay = logic.getCurrentlyFilteredAddresses().filter(addr => addr.verificationData?.initialResult?.latitude);
        if (addressesToDisplay.length === 0) { showToast('لا توجد عناوين تحتوي على إحداثيات في القائمة الحالية.', 'info'); return; }
        root.mapViewContainer.classList.remove('hidden');
        setTimeout(() => {
            const map = initializeMapWithDrawing(root.mapViewMap);
            const markers = [];
            addressesToDisplay.forEach(addr => { const { latitude, longitude } = addr.verificationData.initialResult; const marker = L.marker([latitude, longitude]).addTo(map).bindPopup(`<b>${addr.original}</b><br>${addr.categoryName}`); markers.push(marker); });
            if(markers.length > 0) { const group = new L.featureGroup(markers); map.fitBounds(group.getBounds().pad(0.1)); } else { map.setView([26.3351, 17.2283], 5); }
        }, 150);
    };

    const closeMapView = () => {
        root.mapViewContainer.classList.add('hidden');
        if (mapInstances.has(root.mapViewMap.id)) { mapInstances.get(root.mapViewMap.id).remove(); mapInstances.delete(root.mapViewMap.id); }
    };

    const openShareModal = (address: Address) => {
        if (!address) return;
        root.shareAddressText.textContent = address.original;
        root.sharePlatformsContainer.innerHTML = '';
        const encodedText = encodeURIComponent(address.original);
        const platforms = [ { name: 'WhatsApp', icon: 'bi-whatsapp', href: `https://wa.me/?text=${encodedText}`, className: 'whatsapp' }, { name: 'Telegram', icon: 'bi-telegram', href: `https://t.me/share/url?url=&text=${encodedText}`, className: 'telegram' }, { name: 'Facebook', icon: 'bi-facebook', href: `https://www.facebook.com/sharer/sharer.php?u=&quote=${encodedText}`, className: 'facebook' }, { name: 'X (Twitter)', icon: 'bi-twitter-x', href: `https://twitter.com/intent/tweet?text=${encodedText}`, className: 'twitter' }, { name: 'Email', icon: 'bi-envelope-fill', href: `mailto:?subject=Address&body=${encodedText}`, className: 'email' }, ];
        platforms.forEach(p => { const link = document.createElement('a'); link.href = p.href; link.className = `share-platform-link ${p.className}`; link.target = '_blank'; link.rel = 'noopener noreferrer'; link.innerHTML = `<i class="bi ${p.icon}"></i><span>${p.name}</span>`; root.sharePlatformsContainer.appendChild(link); });
        (root.shareModal.querySelector('[data-action="copy-share-text"]') as HTMLElement).dataset.text = address.original;
        showModal(root.shareModal);
    };

    // --- User Management UI ---
    const updateGreeting = () => {
        if (!logic.appState.userData) return;
        const { name, logo } = logic.appState.userData;
        const hour = new Date().getHours();
        root.greetingEl.textContent = hour < 12 ? `صباح الخير` : `مساء الخير`;
        root.userNameEl.textContent = name;
        if (logo) { root.userLogo.src = logo; root.welcomeLogoPreview.src = logo; tempSelectedLogoSrc = logo; }
        root.controlsArea.classList.remove('hidden');
    };

    const updateTime = () => {
        const now = new Date();
        const timeString = now.toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' });
        const dateString = now.toLocaleDateString('ar-EG', { weekday: 'long', day: 'numeric' });
        const cleanDate = dateString.split(',')[1] || dateString;
        root.localTimeEl.textContent = `${cleanDate.trim()} | ${timeString}`;
    };

    const startClock = () => {
        updateTime();
        if (timeInterval) clearInterval(timeInterval);
        timeInterval = window.setInterval(updateTime, 1000);
    };

    const openLogoSelector = () => {
        const currentLogo = logic.appState.userData ? logic.appState.userData.logo : tempSelectedLogoSrc;
        root.logoSelectorGallery.querySelectorAll('.logo-selector-option').forEach(img => { img.classList.toggle('active', (img as HTMLElement).dataset.logoSrc === currentLogo); });
        showModal(root.logoSelectorModal);
    };

    const handleLogoSelection = (e: Event) => {
        const target = e.target as HTMLImageElement;
        const newLogoSrc = target.dataset.logoSrc;
        if (!newLogoSrc) return;
        tempSelectedLogoSrc = newLogoSrc;
        root.welcomeLogoPreview.src = newLogoSrc;
        if (logic.appState.userData) { logic.handleSaveLogo(newLogoSrc); root.userLogo.src = newLogoSrc; }
        hideModal(root.logoSelectorModal);
    };
    
    const openEditUserModal = () => {
        if (!logic.appState.userData) return;
        root.editUsernameInput.value = logic.appState.userData.name;
        showModal(root.editUserModal);
    };
    
    // --- UI Rendering for Verification and Search ---
    const renderCachedResults = () => {
        const address = logic.appState.addresses.find(a => a.id === logic.appState.editingAddressId);
        if (!address || !address.verificationData) { showToast('لا توجد بيانات محفوظة لهذا العنوان.', 'info'); return; }
        logic.setCurrentVerificationData(address.verificationData);
        const { initialResult, verificationText, isCrossValidated, expert1Answer, expert2Answer, isArbitrated, isHumanVerified } = address.verificationData;
        const confidenceScore = address.confidenceScore || 3;
        renderDeepSearchResults({ initialResult, verificationText, confidenceScore, mode: 'address', isCrossValidated, expert1Answer, expert2Answer, isArbitrated, isHumanVerified });
        (root.smartSearchSaveBtn as HTMLElement).classList.add('hidden');
        root.saveFactBtn.classList.add('hidden');
        root.challengeBtn.classList.remove('hidden');
        showModal(root.smartSearchModal);
    };

    const renderDeepSearchResults = (data) => {
        const { initialResult, verificationText, confidenceScore, mode, isCrossValidated, expert1Answer, expert2Answer, isArbitrated, isHumanVerified } = data;
        root.smartSearchDefaultView.classList.remove('hidden');
        root.smartSearchConflictView.classList.add('hidden');
        root.smartSearchModal.classList.toggle('fact-mode', mode === 'fact');
        root.crossValidationInfo.classList.toggle('hidden', !isCrossValidated);
        root.arbitrationBadge.classList.toggle('hidden', !isArbitrated);
        root.challengeBtn.classList.toggle('hidden', mode === 'fact' || isArbitrated || isHumanVerified);

        if (isCrossValidated) { document.getElementById('expert-1-opinion').textContent = expert1Answer; document.getElementById('expert-2-opinion').textContent = expert2Answer; } else { root.expertOpinionsContainer.classList.add('hidden'); }
        if (mode === 'address') {
            let starsHtml = '';
            const finalScore = isArbitrated || isHumanVerified ? 5 : confidenceScore;
            for (let i = 1; i <= 5; i++) { starsHtml += `<i class="bi star ${i <= finalScore ? 'bi-star-fill filled' : 'bi-star empty'}"></i>`; }
            const confidenceRatingContainer = document.getElementById('confidence-rating');
            if (confidenceRatingContainer) { confidenceRatingContainer.innerHTML = `<div class="stars">${starsHtml}</div>`; }
            let analysisHtml = '';
            if (initialResult.correctedAddress) analysisHtml += `<div class="result-item"><span class="result-label">العنوان المقترح:</span><span class="result-value">${initialResult.correctedAddress}</span></div>`;
            if (initialResult.city) analysisHtml += `<div class="result-item"><span class="result-label">المدينة:</span><span class="result-value">${initialResult.city}</span></div>`;
            root.deepSearchResultsContainer.innerHTML = analysisHtml;
            root.verificationResultsContainer.innerHTML = `<p>${(verificationText || initialResult.reasoning).replace(/\n/g, '<br>')}</p>`;
            if (initialResult.sources && initialResult.sources.length > 0) { root.citedSourcesList.innerHTML = ''; initialResult.sources.forEach(source => { const li = document.createElement('li'); li.className = 'cited-source-item'; const icon = document.createElement('i'); icon.className = 'bi bi-box-arrow-up-right'; const a = document.createElement('a'); a.href = source.uri; a.textContent = source.name || source.uri; a.target = '_blank'; a.rel = 'noopener noreferrer'; li.appendChild(icon); li.appendChild(a); root.citedSourcesList.appendChild(li); }); root.citedSourcesContainer.classList.remove('hidden'); } else { root.citedSourcesContainer.classList.add('hidden'); }
            if (initialResult.latitude && initialResult.longitude && root.mapContainer && typeof L !== 'undefined') { root.mapContainer.classList.remove('hidden'); setTimeout(() => { const map = initializeMapWithDrawing(root.mapContainer); map.setView([initialResult.latitude, initialResult.longitude], 15); L.marker([initialResult.latitude, initialResult.longitude]).addTo(map).bindPopup(initialResult.correctedAddress).openPopup(); }, 150); } else if (root.mapContainer) { if(mapInstances.has(root.mapContainer.id)) { mapInstances.get(root.mapContainer.id).remove(); mapInstances.delete(root.mapContainer.id); } root.mapContainer.classList.add('hidden'); }
        } else if (mode === 'fact') {
             root.deepSearchResultsContainer.innerHTML = '';
             root.verificationResultsContainer.innerHTML = `<p>${verificationText.replace(/\n/g, '<br>')}</p>`;
             if (initialResult && initialResult.locations && initialResult.locations.length >= 2 && root.mapContainer && typeof L !== 'undefined') { root.mapContainer.classList.remove('hidden'); setTimeout(() => { const map = initializeMapWithDrawing(root.mapContainer); const latlngs = initialResult.locations.map(loc => [loc.latitude, loc.longitude]); initialResult.locations.forEach(loc => { L.marker([loc.latitude, loc.longitude]).addTo(map).bindPopup(loc.name); }); L.polyline(latlngs, { color: 'blue' }).addTo(map); map.fitBounds(latlngs, { padding: [50, 50] }); }, 150); } else { if(mapInstances.has(root.mapContainer.id)) { mapInstances.get(root.mapContainer.id).remove(); mapInstances.delete(root.mapContainer.id); } root.mapContainer.classList.add('hidden'); }
        }
    };
    
    const cleanupSmartSearchModal = () => {
        hideModal(root.smartSearchModal);
        root.smartSearchModal.classList.remove('fact-mode');
        root.deepSearchResultsContainer.innerHTML = '';
        root.verificationResultsContainer.innerHTML = '';
        root.citedSourcesList.innerHTML = '';
        if (mapInstances.has(root.mapContainer.id)) { mapInstances.get(root.mapContainer.id).remove(); mapInstances.delete(root.mapContainer.id); }
        if (root.mapContainer) root.mapContainer.classList.add('hidden');
        if (root.citedSourcesContainer) root.citedSourcesContainer.classList.add('hidden');
        root.crossValidationInfo.classList.add('hidden');
        root.expertOpinionsContainer.classList.add('hidden');
        root.arbitrationBadge.classList.add('hidden');
        const confidenceRatingContainer = document.getElementById('confidence-rating');
        if(confidenceRatingContainer) confidenceRatingContainer.innerHTML = '';
        delete (root.smartSearchSaveBtn as HTMLElement).dataset.address;
        delete (root.smartSearchSaveBtn as HTMLElement).dataset.confidence;
        (root.smartSearchSaveBtn as HTMLElement).classList.remove('hidden');
        root.saveFactBtn.classList.add('hidden');
        root.challengeBtn.classList.add('hidden');
        logic.appState.editingAddressId = null;
        logic.setCurrentVerificationData(null);
    };
    
    const renderConflictUI = (conflictingResults) => {
        root.smartSearchDefaultView.classList.add('hidden');
        root.smartSearchConflictView.classList.remove('hidden');
        const grid = root.smartSearchConflictView.querySelector('.conflict-results-grid');
        const template = document.getElementById('conflict-item-template') as HTMLTemplateElement;
        grid.innerHTML = '';
        conflictingResults.forEach((result, index) => {
            const clone = template.content.cloneNode(true);
            const mapContainer = clone.querySelector('.conflict-map-container');
            mapContainer.id = `map-container-conflict-${index}`;
            clone.querySelector('.conflict-address').textContent = result.correctedAddress;
            clone.querySelector('.conflict-city').textContent = result.city;
            clone.querySelector('.conflict-reasoning').textContent = result.reasoning;
            clone.querySelector('[data-action="adopt-result"]').dataset.result = JSON.stringify(result);
            grid.appendChild(clone);
            setTimeout(() => { const map = initializeMapWithDrawing(mapContainer); map.setView([result.latitude, result.longitude], 13); L.marker([result.latitude, result.longitude]).addTo(map).bindPopup(result.correctedAddress).openPopup(); }, 150);
        });
        showModal(root.smartSearchModal);
    };

    const renderGeospatialAnalysisReport = (results) => {
        root.geospatialSummary.textContent = results.summary;
        const statsGrid = root.geospatialStatsGrid;
        statsGrid.innerHTML = '';
        const createStatCard = (label, value, icon) => { const card = document.createElement('div'); card.className = 'stat-card'; card.innerHTML = `<p class="stat-value">${value}</p><p class="stat-label"><i class="bi ${icon}"></i> ${label}</p>`; return card; };
        if(results.directDistanceKm) statsGrid.appendChild(createStatCard('المسافة المباشرة', `${results.directDistanceKm.toFixed(2)} كم`, 'bi-arrows-angle-expand'));
        if(results.drivingDistanceKm) statsGrid.appendChild(createStatCard('مسافة القيادة', `${results.drivingDistanceKm.toFixed(2)} كم`, 'bi-sign-turn-right-fill'));
        if(results.drivingTimeMinutes) statsGrid.appendChild(createStatCard('وقت القيادة المقدر', `~${Math.round(results.drivingTimeMinutes)} دقيقة`, 'bi-clock-history'));
        if(results.areaSqKm) statsGrid.appendChild(createStatCard('المساحة', `${results.areaSqKm.toFixed(3)} كم²`, 'bi-bounding-box'));
        if(results.perimeterKm) statsGrid.appendChild(createStatCard('المحيط', `${results.perimeterKm.toFixed(2)} كم`, 'bi-arrow-repeat'));
        if(results.containedAddressIds && results.containedAddressIds.length > 0) {
            const containedAddresses = logic.appState.addresses.filter(addr => results.containedAddressIds.includes(addr.id));
            const listContainer = root.geospatialContainedAddresses;
            listContainer.innerHTML = '';
            containedAddresses.forEach(addr => { const item = document.createElement('div'); item.className = 'contained-address-item'; item.innerHTML = `<p>${addr.original}</p><span class="category-badge">${addr.categoryName}</span>`; listContainer.appendChild(item); });
            root.geospatialAddressesSection.classList.remove('hidden');
        } else {
            root.geospatialAddressesSection.classList.add('hidden');
        }
        showModal(root.geospatialAnalysisModal);
    };

    const renderCachedFact = (address: Address) => {
        const { initialResult, verificationText, isCrossValidated, expert1Answer, expert2Answer, isArbitrated } = address.verificationData;
        logic.setCurrentVerificationData(address.verificationData);
        logic.appState.editingAddressId = address.id;
        renderDeepSearchResults({ initialResult, verificationText, mode: 'fact', isCrossValidated, isArbitrated, expert1Answer, expert2Answer });
        (root.smartSearchSaveBtn as HTMLElement).classList.add('hidden');
        root.saveFactBtn.classList.add('hidden');
        root.challengeBtn.classList.add('hidden');
        showModal(root.smartSearchModal);
    };

    // --- Action Handlers (call logic, then update UI) ---
    const handleSmartSearchFlow = async (queryOverride?: string, searchType: 'address' | 'fact' = 'address') => {
        const searchQuery = queryOverride || logic.appState.searchQuery;
        if (!searchQuery) { showToast("يرجى كتابة عنوان للبحث عنه.", "info"); return; }
        if (!navigator.onLine) { showModal(root.internetModal); return; }

        if (searchType === 'fact') {
            root.crossValidationModal.querySelector('.cv-stage-status').textContent = 'جارٍ العمل...';
            showModal(root.crossValidationModal);
        } else {
            root.loaderText.textContent = 'جارٍ التحقق من العنوان...';
            showModal(root.loaderModal);
        }

        try {
            const result = await logic.handleSmartSearch(searchQuery, searchType);
            
            if (searchType === 'fact') {
                hideModal(root.crossValidationModal);
                if (result.type === 'success') {
                    renderDeepSearchResults({ ...result.data, mode: 'fact' });
                    root.smartSearchSaveBtn.classList.add('hidden');
                    root.saveFactBtn.classList.remove('hidden');
                    root.challengeBtn.classList.add('hidden');
                    showModal(root.smartSearchModal);
                } else {
                     showToast(result.message || 'حدث خطأ غير متوقع.', 'danger');
                }
            } else {
                hideModal(root.loaderModal);
                if (result.type === 'conflict') {
                    renderConflictUI(result.data);
                } else if (result.type === 'success') {
                    const { correctedAddress } = result.data.initialResult;
                    const { confidenceScore } = result.data;
                    (root.smartSearchSaveBtn as HTMLElement).dataset.address = correctedAddress;
                    (root.smartSearchSaveBtn as HTMLElement).dataset.confidence = confidenceScore.toString();
                    renderDeepSearchResults({ ...result.data, mode: 'address' });
                    root.smartSearchSaveBtn.classList.remove('hidden');
                    root.saveFactBtn.classList.add('hidden');
                    root.challengeBtn.classList.remove('hidden');
                    showModal(root.smartSearchModal);
                } else {
                    showToast(result.message, 'danger');
                }
            }
        } catch (error) {
            console.error("Verification Flow Error:", error);
            hideModal(root.loaderModal);
            hideModal(root.crossValidationModal);
            showToast(error.message || "حدث خطأ أثناء الاتصال بالخادم.", 'danger');
        }
    };
    
    const handleChallengeSubmission = async () => {
        if (logic.challengeTimeoutId) { clearTimeout(logic.challengeTimeoutId); logic.setChallengeTimeoutId(null); }
        root.challengeWarning.classList.add('hidden');
        const userCorrectedAddress = root.challengeAddressInput.value.trim();
        const originalResultText = logic.currentVerificationData?.initialResult?.correctedAddress?.trim();
        if (!userCorrectedAddress || logic.normalizeArabic(userCorrectedAddress) === logic.normalizeArabic(originalResultText)) {
            root.challengeWarning.textContent = 'يرجى إدخال عنوان مختلف. سيتم اعتماد النتيجة الحالية تلقائيًا بعد 5 دقائق إذا لم يتم اتخاذ أي إجراء.';
            root.challengeWarning.classList.remove('hidden');
            const timeoutId = window.setTimeout(() => { showToast('تم اعتماد النتيجة الأصلية لعدم تقديم طعن.', 'info'); autoConfirmOriginalResult(); logic.setChallengeTimeoutId(null); }, 5 * 60 * 1000);
            logic.setChallengeTimeoutId(timeoutId);
            return; 
        }
        const userNotes = root.challengeNotesInput.value.trim();
        hideModal(root.challengeModal);
        root.loaderText.textContent = 'جارٍ إرسال الطعن للتحكيم...';
        showModal(root.loaderModal);
        try {
            const finalResult = await logic.handleChallengeSubmission(userCorrectedAddress, userNotes);
            hideModal(root.loaderModal);
            (root.smartSearchSaveBtn as HTMLElement).dataset.address = finalResult.initialResult.correctedAddress;
            (root.smartSearchSaveBtn as HTMLElement).dataset.confidence = "5";
            renderDeepSearchResults({ ...finalResult, mode: 'address' });
        } catch (error) {
            hideModal(root.loaderModal);
            showToast(error.message || "حدث خطأ أثناء جلسة التحكيم والتحقق.", 'danger');
        }
    };

    const handleSaveSmartSearch = () => {
        const newAddressText = (root.smartSearchSaveBtn as HTMLElement).dataset.address;
        const confidenceScore = parseInt((root.smartSearchSaveBtn as HTMLElement).dataset.confidence, 10);
        if (!newAddressText) { showToast("لا يوجد عنوان للحفظ.", 'info'); return; }
        
        let updatedOrNewAddress: Address | null = null;
        const addressToUpdate = logic.appState.addresses.find(a => a.id === logic.appState.editingAddressId);
        
        // Get the new category from the verification data
        const newCategoryId = logic.currentVerificationData?.initialResult?.categoryId || 'other-locations';
        const assignedCategory = logic.CATEGORIES.find(c => c.id === newCategoryId) || logic.CATEGORIES.find(c => c.id === 'other-locations');

        if (addressToUpdate) {
            addressToUpdate.original = newAddressText;
            addressToUpdate.confidenceScore = logic.currentVerificationData?.isArbitrated || logic.currentVerificationData?.isHumanVerified ? 5 : confidenceScore;
            addressToUpdate.categoryId = assignedCategory.id;
            addressToUpdate.categoryName = assignedCategory.name;
            delete addressToUpdate.isNew;
            if (logic.currentVerificationData) addressToUpdate.verificationData = logic.currentVerificationData;
            updatedOrNewAddress = addressToUpdate;
            showToast('تم تحديث العنوان بنجاح.', 'success');
        } else {
            const newAddress: Address = {
                id: Date.now(),
                original: newAddressText,
                categoryId: assignedCategory.id,
                categoryName: assignedCategory.name,
                modificationHistory: [],
                confidenceScore: logic.currentVerificationData?.isArbitrated || logic.currentVerificationData?.isHumanVerified ? 5 : confidenceScore,
                verificationData: logic.currentVerificationData,
            };
            logic.appState.addresses.push(newAddress);
            updatedOrNewAddress = newAddress;
            showToast('تم حفظ العنوان الجديد بنجاح.', 'success');
        }
        
        logic.saveState();
        logic.recalculateCategoryCounts();
        updateCategoryCountsUI();
        if (updatedOrNewAddress) logic.propagateVerification(updatedOrNewAddress);
        if (logic.appState.addresses.filter(a => a.confidenceScore !== undefined).length % 5 === 0) { setTimeout(() => { alert('لقد قمت بتدقيق عدة عناوين. نوصي بتصدير نسخة احتياطية الآن.'); }, 500); }
        cleanupSmartSearchModal();
        updateReviewNewButton();
        logic.appState.searchQuery = '';
        root.searchInput.value = '';
        render();
    };
    
    const handleSaveFact = () => {
        if (!logic.currentVerificationData || !logic.currentVerificationData.factSummary) { showToast('لا توجد معلومة لحفظها.', 'info'); return; }
        const newFact: Address = { id: Date.now(), original: logic.currentVerificationData.factSummary, categoryId: 'other-locations', categoryName: 'معرفة', modificationHistory: [], isKnowledgeFact: true, confidenceScore: 5, verificationData: logic.currentVerificationData, };
        logic.appState.addresses.unshift(newFact);
        logic.saveState();
        logic.recalculateCategoryCounts();
        updateCategoryCountsUI();
        cleanupSmartSearchModal();
        logic.appState.searchQuery = '';
        root.searchInput.value = '';
        render();
    };

    const autoConfirmOriginalResult = () => {
        if (!logic.currentVerificationData || !logic.currentVerificationData.initialResult) { cleanupSmartSearchModal(); return; }
        logic.currentVerificationData.isHumanVerified = true;
        (root.smartSearchSaveBtn as HTMLElement).dataset.address = logic.currentVerificationData.initialResult.correctedAddress;
        (root.smartSearchSaveBtn as HTMLElement).dataset.confidence = "5";
        handleSaveSmartSearch();
        hideModal(root.challengeModal);
        root.challengeWarning.classList.add('hidden');
    };

    const handleAnalyzeShape = async (drawnItems) => {
        if (!navigator.onLine) { showModal(root.internetModal); return; }
        const layer = drawnItems.getLayers()[0];
        if (!layer) return;
        const geoJSON = layer.toGeoJSON();
        const bounds = layer.getBounds();
        const nearbyAddresses = logic.appState.addresses.filter(addr => { if (!addr.verificationData?.initialResult?.latitude) return false; const latLng = L.latLng(addr.verificationData.initialResult.latitude, addr.verificationData.initialResult.longitude); return bounds.contains(latLng); });
        root.loaderText.textContent = 'جارٍ تحليل الشكل الهندسي...';
        showModal(root.loaderModal);
        try {
            const results = await logic.handleAnalyzeShape(geoJSON, nearbyAddresses);
            hideModal(root.loaderModal);
            renderGeospatialAnalysisReport(results);
        } catch (error) {
            console.error("Geospatial Analysis Error:", error);
            hideModal(root.loaderModal);
            showToast(error.message || "حدث خطأ أثناء تحليل الشكل.", 'danger');
        }
    };

    // --- Import, Export, Backup Flow ---
    const handleExportBackup = () => {
        if (!logic.appState.userData) { showToast("يرجى إعداد ملفك الشخصي أولاً.", 'info'); return; }
        const dataToExport = { userData: logic.appState.userData, addresses: logic.appState.addresses, searchHistory: logic.appState.searchHistory };
        const dataStr = JSON.stringify(dataToExport, null, 2);
        const blob = new Blob([dataStr], { type: "application/json" });
        const url = URL.createObjectURL(blob);
        const link = document.createElement("a");
        link.href = url;
        link.download = `lamora_backup_${new Date().toISOString().split('T')[0]}.json`;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        URL.revokeObjectURL(url);
    };

    const handleExportCleanExcel = () => {
        if (logic.appState.addresses.length === 0) { showToast("لا توجد عناوين لتصديرها.", 'info'); return; }
        const dataForExport = logic.appState.addresses.map(addr => ({ 'العنوان': addr.original, 'التصنيف': addr.categoryName, 'ملاحظات': addr.notes || '', 'مستوى الثقة (نجوم)': addr.confidenceScore || 'لم يتم التحقق', 'نوع المعلومة': addr.isKnowledgeFact ? 'حقيقة معرفية' : 'عنوان', 'تم التحقق المتقاطع': addr.verificationData?.isCrossValidated ? 'نعم' : 'لا', 'تم التحكيم': addr.verificationData?.isArbitrated ? 'نعم' : 'لا' }));
        const worksheet = XLSX.utils.json_to_sheet(dataForExport);
        const workbook = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(workbook, worksheet, 'Addresses');
        worksheet['!cols'] = [{ wch: 50 }, { wch: 20 }, { wch: 30 }, { wch: 20 }, { wch: 20 }, { wch: 20 }, { wch: 15 }];
        XLSX.writeFile(workbook, `lamora_addresses_export_${new Date().toISOString().split('T')[0]}.xlsx`);
    };

    const softResetApplication = () => {
        logic.appState.userData = null; logic.appState.addresses = []; logic.appState.searchHistory = []; logic.appState.categoryCounts = {}; logic.appState.searchQuery = ''; logic.appState.activeCategory = null; logic.appState.reviewingNew = false; logic.appState.editingAddressId = null; logic.appState.displayedItemsCount = logic.ITEMS_PER_PAGE; logic.appState.tempImportData = null;
        root.searchInput.value = ''; root.importStatsContainer.classList.add('hidden'); root.userNameEl.textContent = ''; root.greetingEl.textContent = 'مرحباً'; root.userLogo.src = 'https://img.icons8.com/bubbles/100/user.png'; root.welcomeLogoPreview.src = 'https://img.icons8.com/bubbles/100/user.png'; tempSelectedLogoSrc = 'https://img.icons8.com/bubbles/100/user.png';
        document.querySelectorAll('.modal').forEach(m => hideModal(m as HTMLElement)); root.controlsArea.classList.add('hidden'); root.searchResultsContainer.innerHTML = '';
        logic.recalculateCategoryCounts(); updateCategoryCountsUI(); updateReviewNewButton();
        if (timeInterval) { clearInterval(timeInterval); timeInterval = undefined; }
        showModal(root.welcomeModal);
    };

    const handleConfirmClearAllData = () => {
        try { localStorage.removeItem('lamoraUser'); localStorage.removeItem('lamoraAddresses'); localStorage.removeItem('lamoraSearchHistory'); softResetApplication(); setTimeout(() => { showToast('تم حذف جميع البيانات بنجاح. التطبيق الآن في وضع المصنع.', 'success', 5000); }, 150); }
        catch (e) { console.error("Failed to clear data:", e); showToast("حدث خطأ أثناء محاولة حذف البيانات.", 'danger'); }
    };

    const restoreFromBackup = (file: File) => {
        const reader = new FileReader();
        reader.onload = (event) => {
            try {
                const data = JSON.parse(event.target.result as string);
                if (data && data.userData && Array.isArray(data.addresses)) {
                    const restoredAddresses = data.addresses;
                    restoredAddresses.forEach(addr => { if (!addr.modificationHistory) { addr.modificationHistory = []; } });
                    logic.appState.userData = data.userData; logic.appState.addresses = restoredAddresses; logic.appState.searchHistory = data.searchHistory || [];
                    logic.saveState(); updateGreeting(); startClock(); logic.recalculateCategoryCounts(); updateCategoryCountsUI(); updateReviewNewButton(); render();
                    showToast('تم استعادة النسخة الاحتياطية بنجاح!', 'success');
                } else { showToast('ملف النسخة الاحتياطية غير صالح.', 'danger'); }
            } catch (e) { console.error("Error parsing backup file:", e); showToast('حدث خطأ أثناء قراءة ملف النسخة الاحتياطية.', 'danger'); }
        };
        reader.onerror = () => { showToast('لا يمكن قراءة الملف.', 'danger'); };
        reader.readAsText(file);
    };
    
    const handleProcessInternalReview = () => {
        const modal = root.internalReviewModal; const idsToDelete = new Set<number>(); const corrections = new Map<number, string>(); const decompositions = new Map<number, { baseAddress: string; notes: string }>();
        modal.querySelectorAll('.phonetic-suggestion-item').forEach(itemEl => { const acceptBtn = itemEl.querySelector('[data-action="accept-suggestion"]'); if (acceptBtn.classList.contains('active')) { corrections.set(parseInt(acceptBtn.dataset.originalId, 10), acceptBtn.dataset.correctedText); } });
        modal.querySelectorAll('.decomposed-item').forEach(itemEl => { const acceptBtn = itemEl.querySelector('[data-action="accept-decomposition"]'); if (acceptBtn.classList.contains('active')) { const analysis = JSON.parse(acceptBtn.dataset.analysis); decompositions.set(analysis.id, { baseAddress: analysis.baseAddress, notes: analysis.additionalInfo }); } });
        let initialList = [...logic.appState.tempImportData.addresses];
        initialList.forEach(addr => { if (corrections.has(addr.id)) { addr.original = corrections.get(addr.id); } if (decompositions.has(addr.id)) { const decomp = decompositions.get(addr.id); addr.original = decomp.baseAddress; addr.notes = decomp.notes; } });
        modal.querySelectorAll('.review-group[data-group-type="duplicate"]').forEach(groupEl => { const button = groupEl.querySelector('[data-action="deduplicate-group"]'); if (button && button.disabled) { JSON.parse(button.dataset.groupIds).forEach(id => idsToDelete.add(id)); } });
        modal.querySelectorAll('.review-sub-group').forEach(subGroupEl => { const selectedRadio = subGroupEl.querySelector('input[type="radio"]:checked'); if (!selectedRadio || selectedRadio.value === 'keep-all') return; const primaryId = parseInt(selectedRadio.value, 10); Array.from(subGroupEl.querySelectorAll('input[type="radio"][value]')).map(radio => parseInt(radio.value, 10)).filter(id => !isNaN(id)).forEach(id => { if (id !== primaryId) idsToDelete.add(id); }); });
        logic.appState.tempImportData.addresses = initialList.filter(addr => !idsToDelete.has(addr.id));
        hideModal(modal);
        startSmartImport();
    };
    
    const startInternalAnalysisFlow = async () => {
        showModal(root.loaderModal);
        const useSpellcheck = root.useSpellcheckAnalysisCheckbox.checked;
        const useDecomposition = root.useDecomposeAnalysisCheckbox.checked;
        
        const onProgress = (message: string) => {
            root.loaderText.textContent = message;
        };

        try {
            const { finalSimilarGroups, duplicateGroups, phoneticSuggestions, decompositionResults } = await logic.startInternalAnalysis(useSpellcheck, useDecomposition, onProgress);
            hideModal(root.loaderModal);
            if (finalSimilarGroups.length === 0 && duplicateGroups.length === 0 && phoneticSuggestions.length === 0 && decompositionResults.length === 0) {
                startSmartImport();
            } else {
                renderInternalReviewModal(finalSimilarGroups, duplicateGroups, phoneticSuggestions, decompositionResults);
            }
        } catch (error) {
            hideModal(root.loaderModal);
            showToast(error.message || "فشلت عملية التحليل الداخلي.", 'danger');
        }
    };
    
    const renderInternalReviewModal = (similarGroups, duplicateGroups, phoneticSuggestions, decompositionResults) => {
        const modal = root.internalReviewModal;
        const simList = modal.querySelector('#internal-similar-list'); const dupList = modal.querySelector('#internal-duplicate-list'); const phoneticList = modal.querySelector('#internal-phonetic-list'); const decompositionList = modal.querySelector('#internal-decomposition-list');
        simList.innerHTML = ''; dupList.innerHTML = ''; phoneticList.innerHTML = ''; decompositionList.innerHTML = '';
        modal.querySelector('#internal-similar-count').textContent = similarGroups.length; modal.querySelector('#internal-duplicate-count').textContent = duplicateGroups.length; modal.querySelector('#internal-phonetic-count').textContent = phoneticSuggestions.length; modal.querySelector('#internal-decomposition-count').textContent = decompositionResults.length;
        modal.querySelector('#phonetic-suggestions-section').classList.toggle('hidden', phoneticSuggestions.length === 0);
        modal.querySelector('#decomposition-section').classList.toggle('hidden', decompositionResults.length === 0);
        similarGroups.sort((a, b) => a.superGroup[0].original.localeCompare(b.superGroup[0].original, 'ar'));
        similarGroups.forEach((groupData, groupIndex) => { const superGroupClone = root.similarSuperGroupTemplate.content.cloneNode(true); const superGroupContainer = superGroupClone.querySelector('.similar-super-group'); groupData.subGroups.forEach((subGroupItems, anchor) => { const subGroupClone = root.similarSubGroupTemplate.content.cloneNode(true); const subGroupEl = subGroupClone.querySelector('.review-sub-group'); subGroupEl.querySelector('.sub-group-anchor').textContent = anchor; const radioGroupName = `similar-group-action-${groupIndex}-${anchor}`; subGroupEl.querySelector('input[value="keep-all"]').name = radioGroupName; subGroupItems.forEach(item => { const variationClone = root.similarVariationTemplate.content.cloneNode(true); const radio = variationClone.querySelector('input[type="radio"]'); radio.name = radioGroupName; radio.value = item.id; const variationText = item.original.replace(anchor, '').trim(); variationClone.querySelector('.diff-html').innerHTML = `<span class="highlight-common">${anchor}</span> <span class="highlight-diff">${variationText}</span>`; subGroupEl.appendChild(variationClone); }); superGroupContainer.appendChild(subGroupClone); }); simList.appendChild(superGroupClone); });
        duplicateGroups.sort((a,b) => a[0].original.localeCompare(b[0].original, 'ar'));
        duplicateGroups.forEach(group => { const groupClone = root.duplicateGroupTemplate.content.cloneNode(true); const itemsContainer = groupClone.querySelector('.review-group-items'); group.forEach(item => { const p = document.createElement('p'); p.className = 'review-group-item'; p.textContent = item.original; itemsContainer.appendChild(p); }); groupClone.querySelector('.group-count').textContent = group.length; groupClone.querySelector('[data-action="deduplicate-group"]').dataset.groupIds = JSON.stringify(group.slice(1).map(i => i.id)); dupList.appendChild(groupClone); });
        phoneticSuggestions.sort((a,b) => a.originalText.localeCompare(b.originalText, 'ar'));
        phoneticSuggestions.forEach(suggestion => { const clone = root.phoneticSuggestionTemplate.content.cloneNode(true); clone.querySelector('.original-text').textContent = suggestion.originalText; clone.querySelector('.suggested-text').textContent = suggestion.correctedText; clone.querySelector('.suggestion-reason').textContent = `السبب: ${suggestion.reason}`; const acceptBtn = clone.querySelector('[data-action="accept-suggestion"]'); acceptBtn.dataset.originalId = suggestion.originalId; acceptBtn.dataset.correctedText = suggestion.correctedText; phoneticList.appendChild(clone); });
        decompositionResults.sort((a,b) => a.originalText.localeCompare(b.originalText, 'ar'));
        decompositionResults.forEach(analysis => { const clone = root.decomposedItemTemplate.content.cloneNode(true); clone.querySelector('.original-text-full').textContent = analysis.originalText; clone.querySelector('.base-address').textContent = analysis.baseAddress; clone.querySelector('.additional-info').textContent = analysis.additionalInfo; clone.querySelector('.decomposition-reason').textContent = `السبب: ${analysis.reason}`; clone.querySelector('[data-action="accept-decomposition"]').dataset.analysis = JSON.stringify(analysis); decompositionList.appendChild(clone); });
        showModal(modal);
    };

    const updateImportTimeEstimate = () => {
        if (!logic.appState.tempImportData || !logic.appState.tempImportData.addresses) return;
        const modal = root.importConfirmModal; const timeEstimateEl = modal.querySelector('.time-estimate'); const quotaWarningEl = modal.querySelector('.quota-warning'); const confirmBtn = modal.querySelector('[data-action="confirm-pre-import"]');
        const { cost, estimatedTimeSec, quotaExceeded } = logic.getImportTimeEstimate();
        timeEstimateEl.classList.add('hidden'); quotaWarningEl.classList.add('hidden'); confirmBtn.disabled = false;
        if (cost > 0) {
            if (quotaExceeded) { quotaWarningEl.textContent = `العملية مكلفة (${Math.round(cost)} عملية) وتتجاوز الحصة اليومية. يرجى إلغاء تحديد بعض الخيارات.`; quotaWarningEl.classList.remove('hidden'); confirmBtn.disabled = true; }
            else { const minutes = Math.floor(estimatedTimeSec / 60); const seconds = estimatedTimeSec % 60; timeEstimateEl.textContent = `التكلفة: ~${Math.round(cost)} عملية | الوقت المقدر: ~${minutes} دقيقة و ${seconds} ثانية.`; timeEstimateEl.classList.remove('hidden'); }
        } else { timeEstimateEl.textContent = 'سيتم استخدام التحليل المحلي السريع (فوري).'; timeEstimateEl.classList.remove('hidden'); }
    };

    const processParsedAddresses = (lines: Address[]) => {
        let rejectedCount = 0;
        const validAddresses = lines.filter(addr => { if(logic.isValidAddress(addr.original)) return true; if(addr.original) rejectedCount++; return false; });
        if (validAddresses.length === 0) { hideModal(root.loaderModal); showToast("لم يتم العثور على عناوين صالحة في الملف.", 'info'); return; }
        logic.appState.tempImportData.addresses = validAddresses;
        updateImportStats(validAddresses.length, rejectedCount);
        document.getElementById('current-count-stat').textContent = logic.appState.addresses.length.toString(); document.getElementById('new-count-stat').textContent = validAddresses.length.toString(); document.getElementById('total-count-stat').textContent = (logic.appState.addresses.length + validAddresses.length).toString();
        [root.useSemanticAnalysisCheckbox, root.useSpellcheckAnalysisCheckbox, root.useDecomposeAnalysisCheckbox].forEach(cb => { cb.checked = false; cb.disabled = false; cb.closest('label').classList.remove('disabled'); });
        updateImportTimeEstimate();
        hideModal(root.loaderModal);
        showModal(root.importConfirmModal);
    };

    const handleFileImport = async (file: File) => {
        root.loaderText.textContent = 'تحليل الملف...'; showModal(root.loaderModal);
        logic.appState.tempImportData = { addresses: [], phoneticSuggestions: [], decompositionResults: [], file: file };
        const fileName = file.name.toLowerCase();
        try {
            if (fileName.endsWith('.json')) { restoreFromBackup(file); hideModal(root.loaderModal); return; }
            let lines: string[] = [];
            if (fileName.endsWith('.xlsx') || fileName.endsWith('.xls')) { const data = await file.arrayBuffer(); const workbook = XLSX.read(data); const firstSheet = workbook.Sheets[workbook.SheetNames[0]]; const jsonData = XLSX.utils.sheet_to_json(firstSheet, { header: 1, defval: "" }); lines = jsonData.map(row => (row[0] || '').toString()); }
            else if (fileName.endsWith('.csv') || fileName.endsWith('.tsv') || fileName.endsWith('.txt')) { const text = await file.text(); lines = text.split(/\r?\n/).map(line => (line.split(/,|\t/)[0] || '').trim()); }
            else { hideModal(root.loaderModal); showToast('نوع الملف غير مدعوم. يرجى استخدام .xlsx, .xls, .csv, .tsv, .txt, أو .json.', 'danger'); return; }
            const addressesToAnalyze = lines.map((line, index) => ({ original: line.trim(), id: Date.now() + index, modificationHistory: [], })).filter(addr => logic.isValidAddress(addr.original));
            if (addressesToAnalyze.length === 0) { hideModal(root.loaderModal); showToast("لم يتم العثور على عناوين صالحة في الملف.", 'info'); return; }
            processParsedAddresses(addressesToAnalyze);
        } catch (error) { hideModal(root.loaderModal); console.error("File import error:", error); showToast("حدث خطأ أثناء قراءة الملف.", 'danger'); }
    };
    
    const startSmartImport = async () => {
        if (!logic.appState.tempImportData) return;
        const useSemantic = root.useSemanticAnalysisCheckbox.checked;
        showModal(root.loaderModal);
        
        const onProgress = (message: string) => {
            root.loaderText.textContent = message;
        };

        try {
            const { newItems, duplicateItems, similarPairs } = useSemantic 
                ? await logic.runSemanticImport(onProgress) 
                : await logic.runLocalImport(onProgress);
            
            hideModal(root.loaderModal);
            renderSmartImportModal(newItems, duplicateItems, similarPairs);
        } catch(error) { 
            hideModal(root.loaderModal); 
            console.error("Import process failed:", error); 
            showToast(error.message || "فشلت عملية الاستيراد.", 'danger'); 
        } 
    };
    
    const renderSmartImportModal = (newItems, duplicates, similars) => {
        const modal = root.smartImportModal; const newContainer = modal.querySelector('#new-addresses-list'); const dupContainer = modal.querySelector('#duplicate-addresses-list'); const simContainer = modal.querySelector('#similar-addresses-list');
        newContainer.innerHTML = ''; dupContainer.innerHTML = ''; simContainer.innerHTML = '';
        modal.querySelector('#new-count').textContent = newItems.length; modal.querySelector('#similar-count').textContent = similars.length; modal.querySelector('#duplicate-count').textContent = duplicates.length;
        newItems.sort((a, b) => a.original.localeCompare(b.original, 'ar')); duplicates.sort((a, b) => a.original.localeCompare(b.original, 'ar')); similars.sort((a, b) => a.newAddress.original.localeCompare(b.newAddress.original, 'ar'));
        newItems.forEach(item => { const clone = root.newItemTemplate.content.cloneNode(true); clone.querySelector('.import-item-text').textContent = item.original; clone.querySelector('input').dataset.addressId = item.id.toString(); newContainer.appendChild(clone); });
        duplicates.forEach(item => { const clone = root.duplicateItemTemplate.content.cloneNode(true); clone.querySelector('.import-item-text').textContent = item.original; dupContainer.appendChild(clone); });
        similars.forEach(pair => { const clone = root.similarPairTemplate.content.cloneNode(true); const pairEl = clone.querySelector('.similar-pair'); pairEl.dataset.newAddressId = pair.newAddress.id.toString(); pairEl.dataset.oldAddressId = pair.oldAddress.id.toString(); clone.querySelector('.similar-new .import-item-text').textContent = pair.newAddress.original; clone.querySelector('.similar-old .import-item-text').textContent = pair.oldAddress.original; clone.querySelector('.similarity-reason').textContent = pair.reason; const percentageEl = clone.querySelector('.similarity-percentage'); percentageEl.textContent = `${pair.similarity}%`; if (pair.similarity > 85) percentageEl.classList.add('high'); else if (pair.similarity > 65) percentageEl.classList.add('medium'); else percentageEl.classList.add('low'); const radioName = `similar-option-${pair.newAddress.id}`; clone.querySelectorAll('input[type="radio"]').forEach(radio => radio.name = radioName); simContainer.appendChild(clone); });
        showModal(modal);
    };

    const handleConfirmImport = () => {
        const modal = root.smartImportModal; let addressesToAdd: Address[] = [];
        modal.querySelectorAll('#new-addresses-list .import-item input:checked').forEach(input => { const id = parseInt(input.dataset.addressId, 10); const address = logic.appState.tempImportData.addresses.find(a => a.id === id); if(address) addressesToAdd.push(address); });
        modal.querySelectorAll('.similar-pair').forEach(pairEl => { const newId = parseInt(pairEl.dataset.newAddressId, 10); const oldId = parseInt(pairEl.dataset.oldAddressId, 10); const selectedOption = pairEl.querySelector('input[name^="similar-option"]:checked')?.value; const newAddress = logic.appState.tempImportData.addresses.find(a => a.id === newId); const oldAddress = logic.appState.addresses.find(a => a.id === oldId); if (!newAddress || !oldAddress) return; if (selectedOption === 'use-new') { const originalOld = oldAddress.original; oldAddress.original = newAddress.original; oldAddress.notes = newAddress.notes; oldAddress.categoryId = newAddress.categoryId; oldAddress.categoryName = newAddress.categoryName; if (!oldAddress.modificationHistory) oldAddress.modificationHistory = []; oldAddress.modificationHistory.push({ type: 'edit', from: originalOld, to: newAddress.original, timestamp: new Date().toISOString() }); delete oldAddress.isNew; } else if (selectedOption === 'keep-both') { addressesToAdd.push(newAddress); } });
        let autoVerificationCandidates = [];
        addressesToAdd.forEach(addr => { addr.isNew = true; const normalizedNew = logic.normalizeArabic(addr.original); const verifiedMatch = logic.appState.addresses.find(a => a.confidenceScore && a.confidenceScore >= 4 && logic.normalizeArabic(a.original) === normalizedNew); if(verifiedMatch) { addr.confidenceScore = verifiedMatch.confidenceScore; addr.verificationData = verifiedMatch.verificationData; delete addr.isNew; autoVerificationCandidates.push({newAddr: addr, trustedAddr: verifiedMatch}); } });
        logic.appState.addresses.push(...addressesToAdd);
        logic.appState.addresses.sort((a,b) => (a.id < b.id) ? -1 : 1);
        logic.saveState(); logic.recalculateCategoryCounts(); updateCategoryCountsUI(); updateReviewNewButton(); render(); hideModal(modal);
        showToast(`تم استيراد ${addressesToAdd.length} عنوانًا جديدًا بنجاح!`, 'success');
        if (autoVerificationCandidates.length > 0) { logic.appState.autoVerificationMatches = autoVerificationCandidates; renderAutoVerifyModal(); }
        logic.appState.tempImportData = null;
    };
    
    const renderAutoVerifyModal = () => {
        const listEl = root.autoVerifyList; listEl.innerHTML = '';
        logic.appState.autoVerificationMatches.forEach(match => { const itemClone = root.autoVerifyItemTemplate.content.cloneNode(true); itemClone.querySelector('.new-address').textContent = match.newAddr.original; itemClone.querySelector('.trusted-address').textContent = `(يطابق: ${match.trustedAddr.original})`; listEl.appendChild(itemClone); });
        showModal(root.autoVerifyModal);
    };

    const renderReports = () => {
        const modal = root.reportsModal; const searchStatsContainer = modal.querySelector('#search-stats-content'); const modLogContainer = modal.querySelector('#mod-log-content'); const similarityContainer = modal.querySelector('#similarity-analysis-content');
        searchStatsContainer.innerHTML = ''; const totalSearches = logic.appState.searchHistory.length; const uniqueTerms = new Set(logic.appState.searchHistory.map(s => s.term)).size; const searchFrequency = logic.appState.searchHistory.reduce((acc, s) => { acc[s.term] = (acc[s.term] || 0) + 1; return acc; }, {}); const top5Searches = Object.entries(searchFrequency).sort(([, a], [, b]) => b - a).slice(0, 5); const statsGrid = document.createElement('div'); statsGrid.className = 'stat-grid'; statsGrid.innerHTML = `<div class="stat-card"><p class="stat-value">${totalSearches}</p><p class="stat-label">إجمالي عمليات البحث</p></div><div class="stat-card"><p class="stat-value">${uniqueTerms}</p><p class="stat-label">المصطلحات الفريدة</p></div>`; searchStatsContainer.appendChild(statsGrid); if (top5Searches.length > 0) { const listContainer = document.createElement('div'); listContainer.className = 'top-search-list'; listContainer.innerHTML = '<h4>أكثر 5 مصطلحات بحثًا</h4>'; top5Searches.forEach(([term, count]) => { const item = root.topSearchTemplate.content.cloneNode(true); item.querySelector('.top-search-term').textContent = term; item.querySelector('.top-search-count').textContent = count; listContainer.appendChild(item); }); searchStatsContainer.appendChild(listContainer); }
        modLogContainer.innerHTML = ''; const allModifications = logic.appState.addresses.flatMap(a => a.modificationHistory.map(m => ({ ...m, address: a.original }))).sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()).slice(0, 20); if (allModifications.length > 0) { const logList = document.createElement('div'); logList.className = 'log-list'; logList.innerHTML = '<h4>أحدث 20 تعديلاً</h4>'; allModifications.forEach(mod => { const item = root.logItemTemplate.content.cloneNode(true); item.querySelector('.log-timestamp').textContent = new Date(mod.timestamp).toLocaleString('ar-EG'); item.querySelector('.log-change-type').textContent = mod.type === 'edit' ? `تعديل على "${mod.address}"` : `إعادة تصنيف "${mod.address}"`; item.querySelector('.log-from').textContent = mod.from; item.querySelector('.log-to').textContent = mod.to; logList.appendChild(item); }); modLogContainer.appendChild(logList); } else { modLogContainer.innerHTML = '<p class="empty-state">لا توجد تعديلات مسجلة.</p>'; }
        similarityContainer.innerHTML = ''; const keywordMap = new Map(); logic.appState.addresses.forEach(addr => { const words = logic.normalizeArabic(addr.original).split(' ').filter(w => w.length > 3 && isNaN(w)); words.forEach(word => { if (!keywordMap.has(word)) keywordMap.set(word, new Set()); keywordMap.get(word).add(addr.categoryName); }); }); const crossCategoryKeywords = []; keywordMap.forEach((categories, keyword) => { if (categories.size > 1) { crossCategoryKeywords.push({ keyword, categories: Array.from(categories) }); } }); if (crossCategoryKeywords.length > 0) { const similarityList = document.createElement('div'); similarityList.className = 'similarity-analysis-container'; similarityList.innerHTML = '<h4>الكلمات الرئيسية المشتركة بين التصنيفات</h4>'; crossCategoryKeywords.slice(0, 10).forEach(item => { const group = root.similarityGroupTemplate.content.cloneNode(true); group.querySelector('.similarity-keyword').textContent = `الكلمة: "${item.keyword}"`; const badgesContainer = group.querySelector('.similarity-categories'); item.categories.forEach(catName => { const badge = document.createElement('span'); badge.className = 'similarity-category-badge'; badge.textContent = catName; badgesContainer.appendChild(badge); }); similarityList.appendChild(group); }); similarityContainer.appendChild(similarityList); } else { similarityContainer.innerHTML = '<p class="empty-state">لا توجد كلمات رئيسية مشتركة بشكل كبير بين التصنيفات.</p>'; }
        showModal(modal);
    };

    // --- Initialization & Event Listeners ---
    const checkApiStatus = async () => {
        const { isAiReady } = await logic.checkServerStatus();
        root.apiStatusDot.classList.toggle('ok', isAiReady);
        root.apiStatusDot.classList.toggle('error', !isAiReady);
        root.apiStatusDot.title = isAiReady ? 'الخادم متصل وخدمات الذكاء الاصطناعي جاهزة.' : 'خطأ في الاتصال! خدمات الذكاء الاصطناعي معطلة. انقر للمزيد من التفاصيل.';
    };

    const init = () => {
        logic.initLogic();
        if (logic.appState.userData) {
            updateGreeting();
            startClock();
            checkApiStatus();
        } else {
            showModal(root.welcomeModal);
        }
        updateCategoryCountsUI();
        render();
    };
    
    document.body.addEventListener('click', (e) => {
        const target = e.target as HTMLElement;
        const actionTarget = target.closest('[data-action]');
        
        if (!actionTarget) { const card = target.closest('.address-card, tr[data-id]'); if (card && card.dataset.id) { const id = parseInt(card.dataset.id, 10); const address = logic.appState.addresses.find(a => a.id === id); if (address && address.isKnowledgeFact) { renderCachedFact(address); } } return; }

        const action = actionTarget.dataset.action;
        const card = target.closest('[data-id]');
        const id = card ? parseInt(card.dataset.id, 10) : null;
        if (id) { logic.appState.editingAddressId = id; }

        switch (action) {
            case 'save-user':
                const name = root.usernameInput.value.trim();
                if (!name) { root.usernameInput.classList.add('input-error', 'is-invalid'); root.usernameError?.classList.remove('hidden'); setTimeout(() => { root.usernameInput.classList.remove('is-invalid'); }, 500); return; }
                logic.handleSaveUser(name, root.welcomeLogoPreview.src);
                hideModal(root.welcomeModal); updateGreeting(); startClock(); checkApiStatus(); break;
            case 'open-logo-selector': openLogoSelector(); break;
            case 'open-edit-user': openEditUserModal(); break;
            case 'select-logo': handleLogoSelection(e); break;
            case 'save-username':
                const newName = root.editUsernameInput.value.trim();
                if (newName) {
                    logic.handleSaveUsername(newName);
                    updateGreeting(); 
                }
                hideModal(root.editUserModal); break;
            case 'save-edit':
                const newText = root.editAddressInput.value.trim();
                logic.handleSaveEdit(logic.appState.editingAddressId, newText);
                hideModal(root.editAddressModal); updateReviewNewButton(); updateVerificationStats(); render(); break;
            case 'import': root.fileInput.click(); break;
            case 'export-backup': handleExportBackup(); break;
            case 'open-map-view': openMapView(); break;
            case 'close-map-view': closeMapView(); break;
            case 'open-reports': renderReports(); break;
            case 'open-settings': showModal(root.advancedSettingsModal); break;
            case 'open-about': showModal(root.aboutModal); break;
            case 'toggle-review-new': logic.appState.reviewingNew = !logic.appState.reviewingNew; logic.appState.activeCategory = null; render(); break;
            case 'filter-category': logic.appState.activeCategory = logic.appState.activeCategory === actionTarget.dataset.category ? null : actionTarget.dataset.category; logic.appState.reviewingNew = false; render(); break;
            case 'switch-view': logic.appState.currentView = actionTarget.dataset.view as 'card' | 'table' | 'group'; render(); break;
            case 'edit': if (id) { const address = logic.appState.addresses.find(a => a.id === id); if (address) { root.editAddressInput.value = address.original; showModal(root.editAddressModal); } } break;
            case 'reclassify': if (id) { const address = logic.appState.addresses.find(a => a.id === id); if (address) { root.reclassifySelect.innerHTML = ''; logic.CATEGORIES.forEach(cat => { const option = document.createElement('option'); option.value = cat.id; option.textContent = cat.name; if (cat.id === address.categoryId) { option.selected = true; } root.reclassifySelect.appendChild(option); }); showModal(root.reclassifyAddressModal); } } break;
            case 'delete': if (id) showModal(root.deleteConfirmModal); break;
            case 'copy': const addrToCopy = logic.appState.addresses.find(a => a.id === id); if (addrToCopy) { navigator.clipboard.writeText(addrToCopy.original); showToast('تم نسخ العنوان بنجاح!', 'success'); } break;
            case 'navigate': const addrToNav = logic.appState.addresses.find(a => a.id === id); if (addrToNav?.verificationData?.initialResult?.latitude) { const { latitude, longitude } = addrToNav.verificationData.initialResult; window.open(`https://www.google.com/maps/dir/?api=1&destination=${latitude},${longitude}`, '_blank'); } else { showToast('لا توجد إحداثيات لهذا العنوان.', 'info'); } break;
            case 'verify': const addrToVerify = logic.appState.addresses.find(a => a.id === id); if (addrToVerify) { if ((addrToVerify.confidenceScore || 0) >= 5) { showModal(root.reverifyConfirmModal); } else if (addrToVerify.verificationData) { renderCachedResults(); } else { handleSmartSearchFlow(addrToVerify.original); } } break;
            case 'quick-verify':
                 const addrToQuickVerify = logic.appState.addresses.find(a => a.id === id); const suggested = logic.appState.addresses.find(a => a.id === addrToQuickVerify?.suggestedVerificationId);
                 if (suggested?.verificationData) { logic.setCurrentVerificationData(suggested.verificationData); const ratingContainer = root.quickVerifyModal.querySelector('#quick-verify-rating'); let starsHtml = ''; for (let i = 1; i <= suggested.confidenceScore; i++) { starsHtml += `<i class="bi star bi-star-fill filled"></i>`; } ratingContainer.innerHTML = `<div class="stars">${starsHtml}</div>`; root.quickVerifyModal.querySelector('#quick-verify-results').innerHTML = `<p>${suggested.verificationData.verificationText.replace(/\n/g, '<br>')}</p>`; showModal(root.quickVerifyModal); } break;
            case 'share': const addrToShare = logic.appState.addresses.find(a => a.id === id); if(addrToShare) openShareModal(addrToShare); break;
            case 'load-more': logic.appState.displayedItemsCount += logic.ITEMS_PER_PAGE; render(); break;
            case 'smart-search':
            case 'ask-expert': const queryEl = actionTarget.closest('.not-found-card')?.querySelector('.not-found-query'); if(queryEl) { handleSmartSearchFlow(queryEl.textContent, action === 'ask-expert' ? 'fact' : 'address'); } break;
            case 'close-modal': const modal = actionTarget.closest('.modal'); if (modal) { if(modal.id === 'smart-search-modal') cleanupSmartSearchModal(); else hideModal(modal as HTMLElement); } break;
            case 'save-reclassify': if (logic.appState.editingAddressId) { logic.handleSaveReclassify(logic.appState.editingAddressId, root.reclassifySelect.value); hideModal(root.reclassifyAddressModal); updateCategoryCountsUI(); render(); showToast(`تم تحديث التصنيف بنجاح.`, 'success'); } break;
            case 'confirm-delete': logic.handleConfirmDelete(logic.appState.editingAddressId); hideModal(root.deleteConfirmModal); updateCategoryCountsUI(); updateReviewNewButton(); render(); showToast('تم حذف العنوان بنجاح.', 'success'); break;
            case 'save-smart-search': handleSaveSmartSearch(); break;
            case 'save-fact': handleSaveFact(); break;
            case 'challenge': if (!logic.currentVerificationData) return; root.challengeAddressInput.value = logic.currentVerificationData.initialResult?.correctedAddress || logic.currentVerificationData.originalQuery || ''; root.challengeNotesInput.value = ''; showModal(root.challengeModal); break;
            case 'submit-challenge': handleChallengeSubmission(); break;
            case 'confirm-reverify': hideModal(root.reverifyConfirmModal); renderCachedResults(); break;
            case 'confirm-quick-verify': const addrQuickVerify = logic.appState.addresses.find(a => a.id === logic.appState.editingAddressId); if (addrQuickVerify && logic.currentVerificationData) { addrQuickVerify.verificationData = logic.currentVerificationData; addrQuickVerify.confidenceScore = logic.currentVerificationData.isArbitrated ? 5 : (addrQuickVerify.confidenceScore || 4); delete addrQuickVerify.isNew; delete addrQuickVerify.suggestedVerificationId; logic.saveState(); logic.recalculateCategoryCounts(); updateCategoryCountsUI(); hideModal(root.quickVerifyModal); render(); } break;
            case 'reject-quick-verify': const addrReject = logic.appState.addresses.find(a => a.id === logic.appState.editingAddressId); if (addrReject) { delete addrReject.suggestedVerificationId; logic.saveState(); hideModal(root.quickVerifyModal); handleSmartSearchFlow(addrReject.original); } break;
            case 'adopt-result': const resultData = JSON.parse(actionTarget.dataset.result); logic.setCurrentVerificationData({ initialResult: resultData, verificationText: resultData.reasoning }); (root.smartSearchSaveBtn as HTMLElement).dataset.address = resultData.correctedAddress; (root.smartSearchSaveBtn as HTMLElement).dataset.confidence = "4"; renderDeepSearchResults({ initialResult: resultData, verificationText: resultData.reasoning, confidenceScore: 4, mode: 'address' }); break;
            case 'toggle-expert-opinions': root.expertOpinionsContainer.classList.toggle('hidden'); break;
            case 'export-excel': handleExportCleanExcel(); break;
            case 'open-clear-data-confirm': showModal(root.clearDataConfirmModal); break;
            case 'confirm-clear-data': handleConfirmClearAllData(); hideModal(root.clearDataConfirmModal); break;
            case 'copy-share-text': navigator.clipboard.writeText((actionTarget as HTMLElement).dataset.text); showToast('تم نسخ النص بنجاح!', 'success'); break;
            case 'confirm-pre-import': hideModal(root.importConfirmModal); startInternalAnalysisFlow(); break;
            case 'cancel-pre-import': hideModal(root.importConfirmModal); logic.appState.tempImportData = null; break;
            case 'confirm-import': handleConfirmImport(); break;
            case 'cancel-import': hideModal(root.smartImportModal); logic.appState.tempImportData = null; break;
            case 'continue-to-merge': handleProcessInternalReview(); break;
            case 'cancel-internal-review': hideModal(root.internalReviewModal); logic.appState.tempImportData = null; break;
            case 'confirm-auto-verify': hideModal(root.autoVerifyModal); showToast(`${logic.appState.autoVerificationMatches.length} من العناوين تم تدقيقها تلقائيًا.`, 'info', 5000); logic.appState.autoVerificationMatches = []; render(); break;
            case 'skip-auto-verify': hideModal(root.autoVerifyModal); break;
            case 'toggle-accordion': const header = actionTarget.closest('.accordion-header, .review-group-header'); if (header) { if (target.closest('.btn')) return; const content = header.nextElementSibling; if(content && content.classList.contains('accordion-content')) { header.classList.toggle('active'); if (content.style.maxHeight) { content.style.maxHeight = null; } else { content.style.maxHeight = content.scrollHeight + "px"; } } const catId = (header as HTMLElement).dataset.categoryId; if (catId) { if (logic.appState.expandedCategories.has(catId)) { logic.appState.expandedCategories.delete(catId); } else { logic.appState.expandedCategories.add(catId); } } } break;
            case 'deduplicate-group': actionTarget.textContent = 'تم'; (actionTarget as HTMLButtonElement).disabled = true; break;
            case 'accept-suggestion': case 'reject-suggestion': actionTarget.closest('.suggestion-actions')?.querySelectorAll('button').forEach(b => b.classList.remove('active')); (actionTarget as HTMLButtonElement).classList.add('active'); break;
            case 'accept-decomposition': case 'reject-decomposition': actionTarget.closest('.decomposition-actions')?.querySelectorAll('button').forEach(b => b.classList.remove('active')); (actionTarget as HTMLButtonElement).classList.add('active'); break;
            case 'show-api-status': 
                if (root.apiStatusDot.classList.contains('error')) {
                    showModal(root.apiStatusModal);
                }
                break;
        }
    });

    document.body.addEventListener('change', (e) => {
        const target = e.target as HTMLSelectElement;
        if (target.matches('#sort-select')) { logic.appState.sortOrder = target.value; render(); }
        else if (target.matches('.table-category-select')) { const row = target.closest('tr'); if (row && row.dataset.id) { const id = parseInt(row.dataset.id, 10); logic.handleSaveReclassify(id, target.value); updateCategoryCountsUI(); render(); showToast('تم تحديث التصنيف.', 'success'); } }
        else if (target.matches('#use-semantic-analysis-checkbox, #use-spellcheck-analysis-checkbox, #use-decompose-analysis-checkbox')) { updateImportTimeEstimate(); }
    });

    const debouncedSearch = debounce(() => {
        const query = root.searchInput.value;
        logic.appState.searchQuery = query;
        if (logic.isQuestion(query) || (query.length > 3 && logic.appState.addresses.length > 0)) {
            render();
            logic.appState.searchHistory.unshift({ term: query, timestamp: new Date().toISOString() });
            if(logic.appState.searchHistory.length > 50) logic.appState.searchHistory.pop();
            logic.saveState();
        } else if (!query) {
            render();
        }
    }, 400);

    root.searchInput.addEventListener('input', () => { debouncedSearch(); root.searchInput.style.height = 'auto'; root.searchInput.style.height = (root.searchInput.scrollHeight) + 'px'; });
    root.searchInput.addEventListener('keydown', (e) => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); debouncedSearch.flush(); } });
    root.fileInput.addEventListener('change', () => { if (root.fileInput.files && root.fileInput.files[0]) { handleFileImport(root.fileInput.files[0]); } root.fileInput.value = ''; });

    init();
});
