
// --- Type Definitions ---
export interface UserData {
    name: string;
    logo: string;
}

export interface Modification {
    type: 'edit' | 'reclassify';
    from: string;
    to: string;
    timestamp: string;
}

export interface LocationResult {
    correctedAddress?: string;
    city?: string;
    latitude?: number;
    longitude?: number;
    reasoning?: string;
    sources?: { name: string, uri: string }[];
    locations?: { name:string, latitude: number, longitude: number }[];
    categoryId?: string; // Added for auto-classification
}

export interface VerificationData {
    initialResult: LocationResult;
    verificationText: string;
    factSummary?: string;
    isCrossValidated?: boolean;
    expert1Answer?: string;
    expert2Answer?: string;
    isArbitrated?: boolean;
    isHumanVerified?: boolean;
    originalQuery?: string;
}

export interface StructuredAddress {
    city: string;
    district: string;
    street: string;
    landmark: string;
}

export interface Address {
    id: number;
    original: string;
    categoryId: string;
    categoryName: string;
    modificationHistory: Modification[];
    confidenceScore?: number;
    verificationData?: VerificationData;
    isNew?: boolean;
    isKnowledgeFact?: boolean;
    suggestedVerificationId?: number;
    notes?: string;
    // Properties for import analysis
    structured?: StructuredAddress; 
}

export interface SpellingSuggestion {
    originalId: number;
    originalText: string;
    correctedText: string;
    reason: string;
}

export interface DecomposedAddress {
    id: number;
    originalText: string;
    baseAddress: string;
    additionalInfo: string;
    reason: string;
}

// --- Constants ---
export const CATEGORIES = [
    { id: 'tripoli', name: 'طرابلس' },
    { id: 'tripoli-suburbs', name: 'ضواحي طرابلس' },
    { id: 'misrata', name: 'مصراته' },
    { id: 'benghazi', name: 'بنغازي' },
    { id: 'benghazi-suburbs', name: 'ضواحي بنغازي' },
    { id: 'other-locations', name: 'عناوين لا تتبع الفئات السابقة' },
];

export const ITEMS_PER_PAGE = 20;
const API_BASE_URL = 'http://localhost:3001/api';

// --- Application State ---
interface AppState {
    userData: UserData | null;
    addresses: Address[];
    searchHistory: { term: string; timestamp: string }[];
    categoryCounts: { [key: string]: number };
    searchQuery: string;
    activeCategory: string | null;
    currentView: 'card' | 'table' | 'group';
    sortOrder: string;
    reviewingNew: boolean;
    editingAddressId: number | null;
    displayedItemsCount: number;
    expandedCategories: Set<string>;
    // Import flow state
    tempImportData: { 
        file: File | null;
        addresses: Address[]; 
        phoneticSuggestions: SpellingSuggestion[], 
        decompositionResults: DecomposedAddress[] 
    } | null;
    autoVerificationMatches: { newAddr: Address, trustedAddr: Address }[];
}

export let appState: AppState = {
    userData: null,
    addresses: [],
    searchHistory: [],
    categoryCounts: {},
    searchQuery: '',
    activeCategory: null,
    currentView: 'card',
    sortOrder: 'default',
    reviewingNew: false,
    editingAddressId: null,
    displayedItemsCount: ITEMS_PER_PAGE,
    expandedCategories: new Set(),
    tempImportData: null,
    autoVerificationMatches: [],
};

export let currentVerificationData: VerificationData | null = null;
export let challengeTimeoutId: number | null = null;

// --- State Management ---
export const initLogic = () => {
    try {
        const user = localStorage.getItem('lamoraUser');
        const addrs = localStorage.getItem('lamoraAddresses');
        const history = localStorage.getItem('lamoraSearchHistory');
        
        if (user) appState.userData = JSON.parse(user);
        if (addrs) appState.addresses = JSON.parse(addrs);
        if (history) appState.searchHistory = JSON.parse(history);
        
        recalculateCategoryCounts();
    } catch (e) {
        console.error("Failed to load state from localStorage", e);
        // Clear potentially corrupted storage
        localStorage.removeItem('lamoraUser');
        localStorage.removeItem('lamoraAddresses');
        localStorage.removeItem('lamoraSearchHistory');
    }
};

export const saveState = () => {
    try {
        if (appState.userData) localStorage.setItem('lamoraUser', JSON.stringify(appState.userData));
        localStorage.setItem('lamoraAddresses', JSON.stringify(appState.addresses));
        localStorage.setItem('lamoraSearchHistory', JSON.stringify(appState.searchHistory));
    } catch (e) {
        console.error("Failed to save state to localStorage", e);
    }
};

export const recalculateCategoryCounts = () => {
    const counts = {};
    CATEGORIES.forEach(cat => counts[cat.id] = 0);
    appState.addresses.forEach(addr => {
        if (counts[addr.categoryId] !== undefined) {
            counts[addr.categoryId]++;
        } else { // Handle legacy categories if they exist
            if (!counts['other-locations']) counts['other-locations'] = 0;
            counts['other-locations']++;
            addr.categoryId = 'other-locations';
            addr.categoryName = CATEGORIES.find(c => c.id === 'other-locations').name;
        }
    });
    appState.categoryCounts = counts;
};

// --- API Communication ---
const _fetchAPI = async (endpoint: string, body?: object, method: 'POST' | 'GET' = 'POST') => {
    const response = await fetch(`${API_BASE_URL}${endpoint}`, {
        method,
        headers: { 
            'Content-Type': 'application/json',
            // Add cache-control headers to prevent stale responses, especially for status checks
            'Cache-Control': 'no-cache, no-store, must-revalidate',
            'Pragma': 'no-cache',
            'Expires': '0'
        },
        body: method === 'POST' ? JSON.stringify(body) : undefined,
    });
    if (!response.ok) {
        const errorData = await response.json().catch(() => ({ message: `Server responded with status ${response.status}` }));
        throw new Error(errorData.message || `An unknown server error occurred.`);
    }
    return response.json();
};

export const checkServerStatus = async (): Promise<{ isAiReady: boolean }> => {
    try {
        return await _fetchAPI('/status', undefined, 'GET');
    } catch (error) {
        console.error("Failed to fetch server status:", error);
        // If we can't even reach the server, assume AI is not ready.
        return { isAiReady: false };
    }
};

export const handleSmartSearch = (searchQuery, searchType) => {
    return _fetchAPI('/smart-search', { searchQuery, searchType });
};

export const handleChallengeSubmission = (userCorrectedAddress, userNotes) => {
    return _fetchAPI('/challenge', { userCorrectedAddress, userNotes, currentVerificationData });
};

export const handleAnalyzeShape = (geoJSON, nearbyAddresses) => {
    return _fetchAPI('/analyze-shape', { geoJSON, nearbyAddresses });
};

// --- User & Address Handlers ---
export const handleSaveUser = (name, logo) => {
    appState.userData = { name, logo };
    saveState();
};
export const handleSaveUsername = (name) => {
    if (appState.userData && name) {
        appState.userData.name = name;
        saveState();
    }
};

export const handleSaveLogo = (logoSrc: string) => {
    if (appState.userData && logoSrc) {
        appState.userData.logo = logoSrc;
        saveState();
    }
};


export const handleSaveEdit = (id, newText) => {
    const address = appState.addresses.find(a => a.id === id);
    if (address && newText) {
        const originalText = address.original;
        address.original = newText;
        address.modificationHistory.push({ type: 'edit', from: originalText, to: newText, timestamp: new Date().toISOString() });
        delete address.isNew;
        saveState();
    }
};

export const handleSaveReclassify = (id, newCategoryId) => {
    const address = appState.addresses.find(a => a.id === id);
    const newCategory = CATEGORIES.find(c => c.id === newCategoryId);
    if (address && newCategory) {
        const oldCategoryName = address.categoryName;
        address.categoryId = newCategory.id;
        address.categoryName = newCategory.name;
        address.modificationHistory.push({ type: 'reclassify', from: oldCategoryName, to: newCategory.name, timestamp: new Date().toISOString() });
        delete address.isNew;
        saveState();
    }
};

export const handleConfirmDelete = (id) => {
    appState.addresses = appState.addresses.filter(a => a.id !== id);
    saveState();
};

// --- Data Getters & Filtering ---
export const getVerificationStats = () => {
    return appState.addresses.reduce((acc, addr) => {
        if ((addr.confidenceScore ?? 0) >= 4) {
            acc.trustedCount++;
        } else if (addr.confidenceScore !== undefined) {
            acc.needsReviewCount++;
        } else {
            acc.unverifiedCount++;
        }
        return acc;
    }, { trustedCount: 0, needsReviewCount: 0, unverifiedCount: 0 });
};

export const getCurrentlyFilteredAddresses = (): Address[] => {
    let filtered = appState.addresses;

    if (appState.reviewingNew) {
        return filtered.filter(a => a.isNew);
    }
    
    if (appState.activeCategory) {
        filtered = filtered.filter(a => a.categoryId === appState.activeCategory);
    }
    
    const query = normalizeArabic(appState.searchQuery.trim());
    if (query) {
        filtered = filtered.filter(a => normalizeArabic(a.original).includes(query));
    }
    
    return filtered;
}

export const getFilteredAndSortedAddresses = (): Address[] => {
    let addresses = getCurrentlyFilteredAddresses();

    switch (appState.sortOrder) {
        case 'alpha-asc':
            addresses.sort((a, b) => a.original.localeCompare(b.original, 'ar'));
            break;
        case 'alpha-desc':
            addresses.sort((a, b) => b.original.localeCompare(a.original, 'ar'));
            break;
        case 'confidence-desc':
            addresses.sort((a, b) => (b.confidenceScore ?? -1) - (a.confidenceScore ?? -1));
            break;
        case 'confidence-asc':
            addresses.sort((a, b) => (a.confidenceScore ?? -1) - (b.confidenceScore ?? -1));
            break;
        default: // 'default' or by id
            addresses.sort((a,b) => (a.id < b.id) ? -1 : 1);
            break;
    }
    return addresses;
};

// --- Utility & Helper Functions ---
export const normalizeArabic = (str: string): string => {
    if (!str) return '';
    return str.replace(/[أإآ]/g, 'ا').replace(/[ى]/g, 'ي').replace(/[ؤ]/g, 'و').replace(/[ة]/g, 'ه').toLowerCase().trim();
};

export const isQuestion = (query: string): boolean => {
    const questionWords = ['ما', 'هل', 'كيف', 'متى', 'أين', 'كم', 'لماذا', 'من'];
    return questionWords.some(word => query.trim().startsWith(word));
};

export const isValidAddress = (text: string): boolean => {
    if (!text || typeof text !== 'string') return false;
    const trimmed = text.trim();
    return trimmed.length > 3 && /\s/.test(trimmed); // At least 4 chars and contains a space
};

export const setCurrentVerificationData = (data: VerificationData | null) => {
    currentVerificationData = data;
};

export const setChallengeTimeoutId = (id: number | null) => {
    challengeTimeoutId = id;
};

// --- Advanced Logic for Verification & Import ---
export const propagateVerification = (verifiedAddress: Address) => {
    if (!verifiedAddress.verificationData || (verifiedAddress.confidenceScore ?? 0) < 4) return;

    const normalizedVerified = normalizeArabic(verifiedAddress.original);
    appState.addresses.forEach(addr => {
        if (!addr.verificationData && normalizeArabic(addr.original) === normalizedVerified) {
            addr.suggestedVerificationId = verifiedAddress.id;
        }
    });
    saveState();
};

const BATCH_SIZE = 10;
export const startInternalAnalysis = async (useSpellcheck: boolean, useDecomposition: boolean, onProgress: (message: string) => void) => {
    const addressesToAnalyze = appState.tempImportData.addresses;
    let phoneticSuggestions: SpellingSuggestion[] = [];
    let decompositionResults: DecomposedAddress[] = [];
    let processedCount = 0;

    for (let i = 0; i < addressesToAnalyze.length; i += BATCH_SIZE) {
        const batch = addressesToAnalyze.slice(i, i + BATCH_SIZE);
        const results = await _fetchAPI('/batch-analyze-internal', { batch, useSpellcheck, useDecomposition });
        
        if(results.phoneticSuggestions) phoneticSuggestions.push(...results.phoneticSuggestions);
        if(results.decompositionResults) decompositionResults.push(...results.decompositionResults);

        processedCount += batch.length;
        onProgress(`جارٍ التحليل الداخلي... (${processedCount}/${addressesToAnalyze.length})`);
    }
    
    // Simple local duplicate check
    const seen = new Set();
    const duplicateGroups = [];
    const uniqueAddresses = [];
    const tempAddresses = [...appState.tempImportData.addresses];
    
    tempAddresses.forEach(addr => {
        const normalized = normalizeArabic(addr.original);
        if(seen.has(normalized)) {
            let group = duplicateGroups.find(g => normalizeArabic(g[0].original) === normalized);
            if(group) {
                group.push(addr);
            } else {
                const originalAddr = uniqueAddresses.find(ua => normalizeArabic(ua.original) === normalized);
                if(originalAddr) duplicateGroups.push([originalAddr, addr]);
            }
        } else {
            seen.add(normalized);
            uniqueAddresses.push(addr);
        }
    });

    // Simple local similarity check
    const finalSimilarGroups = []; // This would be very complex to implement locally, so we'll return empty for now.

    return { finalSimilarGroups, duplicateGroups, phoneticSuggestions, decompositionResults };
};

export const getImportTimeEstimate = () => {
    const useSemantic = (document.getElementById('use-semantic-analysis-checkbox') as HTMLInputElement).checked;
    const useSpellcheck = (document.getElementById('use-spellcheck-analysis-checkbox') as HTMLInputElement).checked;
    const useDecompose = (document.getElementById('use-decompose-analysis-checkbox') as HTMLInputElement).checked;
    const addressCount = appState.tempImportData?.addresses?.length || 0;
    
    let cost = 0;
    if(useSpellcheck) cost += addressCount;
    if(useDecompose) cost += addressCount;
    if(useSemantic) cost += addressCount;
    
    const estimatedTimeSec = Math.round(cost * 0.5); // Estimate 0.5 sec per operation
    const quotaExceeded = false; // Placeholder for real quota check
    return { cost, estimatedTimeSec, quotaExceeded };
}

export const runLocalImport = async (onProgress: (message: string) => void): Promise<{ newItems: Address[], duplicateItems: Address[], similarPairs: any[] }> => {
    return new Promise((resolve, reject) => {
        if (!appState.tempImportData || !Array.isArray(appState.tempImportData.addresses)) {
            return reject(new Error("Local import called with no temporary data."));
        }
        
        // Use `new URL` for robust worker creation that works with bundlers.
        const worker = new Worker(new URL('./worker.ts', import.meta.url), { type: 'module' });

        worker.onmessage = (event) => {
            const { type, payload, message } = event.data;
            if (type === 'progress') {
                onProgress(message);
            } else if (type === 'done') {
                onProgress('اكتمل التحليل. جارٍ عرض النتائج...');
                worker.terminate();
                resolve(payload);
            } else if (type === 'error') {
                console.error("Error from worker:", message);
                worker.terminate();
                reject(new Error(`An error occurred in the analysis worker: ${message}`));
            }
        };

        worker.onerror = (error) => {
             // Diagnostic check for file:// protocol issues
            if (window.location.protocol === 'file:') {
                const detailedError = 'لا يمكن تشغيل ميزة التحليل المحلي من ملف مباشر (file://). يرجى تشغيل التطبيق عبر خادم ويب محلي (مثل الذي يأتي مع المشروع) للوصول إلى هذه الميزة المتقدمة.';
                console.error("Worker instantiation error:", detailedError, error);
                worker.terminate();
                reject(new Error(detailedError));
            } else {
                console.error("Worker instantiation error:", error);
                worker.terminate();
                reject(new Error(`Failed to run analysis worker: ${error.message}`));
            }
        };

        onProgress('بدء التحليل المحلي في الخلفية...');
        worker.postMessage({
            existingAddresses: appState.addresses,
            newAddresses: appState.tempImportData.addresses,
        });
    });
};


export const runSemanticImport = async (onProgress: (message: string) => void) => {
    const newAddresses = appState.tempImportData.addresses;
    if (newAddresses.length === 0) return { newItems: [], duplicateItems: [], similarPairs: [] };

    // Structure existing and new addresses
    const allAddressesToStructure = [...appState.addresses, ...newAddresses];
    const structuredDataMap = new Map<number, StructuredAddress>();
    
    for (let i = 0; i < allAddressesToStructure.length; i += BATCH_SIZE) {
        const batch = allAddressesToStructure.slice(i, i + BATCH_SIZE);
        const { structuredResults } = await _fetchAPI('/batch-structure-addresses', { batch });
        structuredResults.forEach(res => {
            if(res.structured) structuredDataMap.set(res.id, res.structured);
        });
        onProgress(`تحليل البنية الدلالية... (${Math.min(i + BATCH_SIZE, allAddressesToStructure.length)}/${allAddressesToStructure.length})`);
    }
    
    appState.addresses.forEach(addr => addr.structured = structuredDataMap.get(addr.id));
    newAddresses.forEach(addr => addr.structured = structuredDataMap.get(addr.id));
    
    const newItems = [];
    const duplicateItems = [];
    const similarPairs = [];

    newAddresses.forEach(newAddr => {
        let bestMatch = null;
        let highestScore = 0;
        
        appState.addresses.forEach(oldAddr => {
            const score = calculateSimilarity(newAddr.structured, oldAddr.structured);
            if (score > highestScore) {
                highestScore = score;
                bestMatch = oldAddr;
            }
        });

        if (highestScore > 95) { // Duplicate
            duplicateItems.push(newAddr);
        } else if (highestScore > 50) { // Similar
            similarPairs.push({
                newAddress: newAddr,
                oldAddress: bestMatch,
                similarity: Math.round(highestScore),
                reason: 'تشابه في اسم الشارع والمنطقة' // Placeholder reason
            });
        } else { // New
            newItems.push(newAddr);
        }
    });
    
    return { newItems, duplicateItems, similarPairs };
};

const calculateSimilarity = (struct1: StructuredAddress, struct2: StructuredAddress): number => {
    if (!struct1 || !struct2) return 0;
    let score = 0;
    const weights = { street: 0.5, district: 0.3, city: 0.15, landmark: 0.05 };
    
    if (normalizeArabic(struct1.street) === normalizeArabic(struct2.street)) score += weights.street;
    if (normalizeArabic(struct1.district) === normalizeArabic(struct2.district)) score += weights.district;
    if (normalizeArabic(struct1.city) === normalizeArabic(struct2.city)) score += weights.city;
    if (struct1.landmark && struct2.landmark && normalizeArabic(struct1.landmark) === normalizeArabic(struct2.landmark)) score += weights.landmark;
    
    return score * 100;
};
